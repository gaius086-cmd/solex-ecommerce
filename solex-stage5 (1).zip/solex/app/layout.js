import "./globals.css";
import { Archivo_Black, Inter } from "next/font/google";
import CartProvider from "@/components/CartProvider";
import WishlistProvider from "@/components/WishlistProvider";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
const display = Archivo_Black({ subsets: ["latin"], weight: "400", variable: "--font-display" });
const body = Inter({ subsets: ["latin"], variable: "--font-body" });
export const metadata = { title: "SOLEX | Footwear", description: "Sneakers, running, boots and formal shoes." };
export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body><CartProvider><WishlistProvider><Header /><main>{children}</main><Footer /></WishlistProvider></CartProvider></body>
    </html>
  );
}
