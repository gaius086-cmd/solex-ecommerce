import Link from "next/link";
import ProductGrid from "@/components/ProductGrid";
import { getProducts } from "@/lib/supabase";
export const dynamic = "force-dynamic";
export default async function Shop({ searchParams }) {
  const { q, brand, category, gender, maxPrice, size, flag } = searchParams;
  const f = flag === "sale" ? undefined : flag;
  const { data, error } = await getProducts({ q, brand, category, gender, maxPrice, size, flag: f });
  const list = flag === "sale" ? data.filter((p) => p.sale_price && p.sale_price < p.price) : data;
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="font-display text-4xl mb-6">{gender ? gender[0].toUpperCase() + gender.slice(1) : flag === "sale" ? "Sale" : "Shop"}</h1>
      <form className="grid grid-cols-2 md:grid-cols-6 gap-3 mb-10 text-sm">
        <input name="q" defaultValue={q} placeholder="Search" aria-label="Search" className="border border-line px-3 py-2" />
        <input name="brand" defaultValue={brand} placeholder="Brand (e.g. nike)" aria-label="Brand" className="border border-line px-3 py-2" />
        <input name="category" defaultValue={category} placeholder="Category (e.g. boots)" aria-label="Category" className="border border-line px-3 py-2" />
        <input name="maxPrice" type="number" defaultValue={maxPrice} placeholder="Max price (₦)" aria-label="Max price" className="border border-line px-3 py-2" />
        <select name="size" defaultValue={size || ""} aria-label="Size" className="border border-line px-3 py-2"><option value="">Any size</option>{[36,37,38,39,40,41,42,43,44,45,46,47].map((s) => <option key={s} value={s}>EU {s}</option>)}</select>
        <div className="flex gap-2"><button className="btn flex-1">Apply</button><Link href="/shop" className="btn-out">Clear</Link></div>
      </form>
      <ProductGrid products={list} error={error} />
    </div>
  );
}
