import AuthShell from "@/components/AuthShell";
import { forgotPassword } from "../login/actions";
export default function Forgot({ searchParams }) {
  return (
    <AuthShell title="Reset password" error={searchParams.error === "expired" ? "Your reset link expired. Request a new one." : null} notice={searchParams.sent ? "If an account exists for that email, a reset link is on its way." : null}>
      <form action={forgotPassword} className="grid gap-3">
        <input name="email" type="email" required placeholder="Email" aria-label="Email" autoComplete="email" className="field" />
        <button className="btn">Send reset link</button>
      </form>
    </AuthShell>
  );
}
