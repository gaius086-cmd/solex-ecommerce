import Link from "next/link";
import { redirect } from "next/navigation";
import AuthShell from "@/components/AuthShell";
import { serverClient } from "@/lib/supabase-server";
import { isConfigured } from "@/lib/supabase";
import { login } from "./actions";
const E = { invalid: "Email or password is incorrect.", unconfirmed: "Please confirm your email first. Check your inbox for the link.", link: "That link is invalid or has expired. Please try again.", config: "Supabase is not configured. Add your keys to .env.local." };
export default async function Login({ searchParams }) {
  if (isConfigured) { const { data: { user } } = await serverClient().auth.getUser(); if (user) redirect("/account"); }
  return (
    <AuthShell title="Log in" error={E[searchParams.error]}>
      <form action={login} className="grid gap-3">
        <input type="hidden" name="next" value={searchParams.next || ""} />
        <input name="email" type="email" required placeholder="Email" aria-label="Email" autoComplete="email" className="field" />
        <input name="password" type="password" required placeholder="Password" aria-label="Password" autoComplete="current-password" className="field" />
        <button className="btn">Log in</button>
      </form>
      <p className="mt-5 text-sm flex justify-between"><Link href="/forgot-password" className="underline">Forgot password?</Link><Link href="/register" className="underline">Create account</Link></p>
    </AuthShell>
  );
}
