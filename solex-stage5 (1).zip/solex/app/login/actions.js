"use server";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { serverClient } from "@/lib/supabase-server";
import { safeNext } from "@/lib/util";
const s = (fd, k) => String(fd.get(k) || "").trim();
const origin = () => process.env.NEXT_PUBLIC_SITE_URL || headers().get("origin") || "http://localhost:3000";
const q = (p, o) => `${p}?${new URLSearchParams(o)}`;
export async function login(fd) {
  const next = safeNext(s(fd, "next"));
  const { error } = await serverClient().auth.signInWithPassword({ email: s(fd, "email"), password: String(fd.get("password") || "") });
  if (error) redirect(q("/login", { error: error.code === "email_not_confirmed" ? "unconfirmed" : "invalid", next }));
  redirect(next);
}
export async function register(fd) {
  const email = s(fd, "email"), password = String(fd.get("password") || ""), name = s(fd, "full_name");
  if (!name) redirect(q("/register", { error: "name" }));
  if (password.length < 8) redirect(q("/register", { error: "short" }));
  if (password !== String(fd.get("confirm") || "")) redirect(q("/register", { error: "match" }));
  const { data, error } = await serverClient().auth.signUp({ email, password, options: { data: { full_name: name }, emailRedirectTo: `${origin()}/auth/callback?next=/account` } });
  if (error) redirect(q("/register", { error: error.code === "weak_password" ? "short" : "failed" }));
  redirect(data.session ? "/account" : "/register?sent=1"); // session exists only if email confirmation is switched off
}
export async function forgotPassword(fd) {
  // Same response whether or not the email exists (no account enumeration)
  await serverClient().auth.resetPasswordForEmail(s(fd, "email"), { redirectTo: `${origin()}/auth/callback?next=/reset-password` });
  redirect("/forgot-password?sent=1");
}
export async function resetPassword(fd) {
  const supabase = serverClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/forgot-password?error=expired");
  const pw = String(fd.get("password") || "");
  if (pw.length < 8) redirect("/reset-password?error=short");
  if (pw !== String(fd.get("confirm") || "")) redirect("/reset-password?error=match");
  const { error } = await supabase.auth.updateUser({ password: pw });
  if (error) redirect("/reset-password?error=failed");
  redirect("/account?pw=1");
}
export async function logout() { await serverClient().auth.signOut(); redirect("/"); }
