import Link from "next/link";
import ProductGrid from "@/components/ProductGrid";
import { getProducts, getPromos, naira } from "@/lib/supabase";
export const revalidate = 60;
const brands = ["Nike","Adidas","Jordan","Puma","New Balance","Converse","Vans","Reebok"];
const cats = ["Sneakers","Running","Basketball","Lifestyle","Training","Slides","Boots","Formal"];
const Section = ({ title, href, children }) => (
  <section className="mx-auto max-w-7xl px-4 mt-20">
    <div className="flex items-end justify-between mb-6"><h2 className="font-display text-3xl">{title}</h2><Link href={href} className="text-sm underline underline-offset-4">View all</Link></div>{children}
  </section>
);
export default async function Home() {
  const [feat, best, fresh, promos] = await Promise.all([getProducts({ flag: "is_featured", limit: 4 }), getProducts({ flag: "is_best_seller", limit: 4 }), getProducts({ limit: 4 }), getPromos()]);
  return (
    <>
      <section className="bg-ink text-paper overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 pt-16 pb-12 md:pt-24">
          <h1 className="font-display leading-[0.85] tracking-tighter text-[26vw] md:text-[19rem] select-none">SOLEX</h1>
          <div className="mt-8 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <p className="max-w-md text-neutral-300">Every pair is footwear, nothing else. Shop sneakers, running, boots and formal shoes from eight leading brands.</p>
            <div className="flex gap-3"><Link href="/shop" className="inline-flex bg-paper text-ink px-7 py-3 text-sm font-semibold">Shop all shoes</Link><Link href="/shop?flag=sale" className="inline-flex border border-paper px-7 py-3 text-sm font-semibold">See the sale</Link></div>
          </div>
        </div>
      </section>
      {promos.length > 0 && <section aria-label="Offers" className="mx-auto max-w-7xl px-4 mt-6 grid gap-2">{promos.map((d) => <p key={d.code} className="border border-ink px-4 py-3 text-sm"><b>{d.type === "percent" ? `${d.percent}% off` : `${naira(d.amount)} off`}</b> with code <b className="tracking-wide">{d.code}</b>{d.min_subtotal > 0 ? ` on orders over ${naira(d.min_subtotal)}` : ""}{d.description ? `. ${d.description}` : ""}</p>)}</section>}
      <section className="mx-auto max-w-7xl px-4 mt-12 grid grid-cols-2 md:grid-cols-4 gap-px bg-line border border-line">
        {cats.map((c) => <Link key={c} href={`/shop?category=${c.toLowerCase()}`} className="bg-paper p-6 text-sm font-semibold hover:bg-mist transition">{c}</Link>)}
      </section>
      <Section title="Featured" href="/shop?flag=is_featured"><ProductGrid {...feat} empty="No featured shoes yet. Mark products as featured in the admin dashboard." /></Section>
      <Section title="Best sellers" href="/shop?flag=is_best_seller"><ProductGrid {...best} empty="No best sellers yet." /></Section>
      <Section title="New arrivals" href="/shop"><ProductGrid {...fresh} empty="No products yet. Add your first shoe in /admin." /></Section>
      <section id="brands" className="mx-auto max-w-7xl px-4 mt-20">
        <h2 className="font-display text-3xl mb-6">Brands</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">{brands.map((b) => <Link key={b} href={`/shop?brand=${b.toLowerCase().replace(/ /g, "-")}`} className="border border-line py-8 text-center font-semibold hover:bg-ink hover:text-paper transition">{b}</Link>)}</div>
      </section>
    </>
  );
}
