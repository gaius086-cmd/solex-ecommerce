import { NextResponse } from "next/server";
import { serverClient } from "@/lib/supabase-server";
import { safeNext } from "@/lib/util";
// Email confirmation and password-reset links land here with ?code=...
export async function GET(request) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const next = safeNext(url.searchParams.get("next"));
  if (code) {
    const { error } = await serverClient().auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(new URL(next, url.origin));
  }
  return NextResponse.redirect(new URL("/login?error=link", url.origin));
}
