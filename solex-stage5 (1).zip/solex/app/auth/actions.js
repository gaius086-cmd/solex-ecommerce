"use server";
import { redirect } from "next/navigation";
import { serverClient } from "@/lib/supabase-server";
import { safeNext } from "@/lib/auth";
const site = () => process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
const s = (f, k) => String(f.get(k) || "").trim();
const emailOk = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && e.length <= 254;

export async function login(formData) {
  const next = safeNext(s(formData, "next"));
  const supabase = serverClient();
  const { error } = await supabase.auth.signInWithPassword({ email: s(formData, "email"), password: String(formData.get("password") || "") });
  if (error) redirect(`/login?error=${encodeURIComponent(error.message.toLowerCase().includes("confirm") ? "Please confirm your email first. Check your inbox." : "Email or password is incorrect.")}&next=${encodeURIComponent(next)}`);
  redirect(next);
}
export async function register(formData) {
  const name = s(formData, "full_name"), email = s(formData, "email"), pw = String(formData.get("password") || "");
  const back = (m) => redirect(`/register?error=${encodeURIComponent(m)}`);
  if (name.length < 2 || name.length > 100) back("Enter your full name.");
  if (!emailOk(email)) back("Enter a valid email address.");
  if (pw.length < 8) back("Password must be at least 8 characters.");
  if (pw !== String(formData.get("confirm") || "")) back("Passwords do not match.");
  const supabase = serverClient();
  const { data, error } = await supabase.auth.signUp({ email, password: pw, options: { data: { full_name: name }, emailRedirectTo: `${site()}/auth/callback?next=/account` } });
  if (error) back(error.message);
  if (data.session) redirect("/account"); // email confirmation is switched off in Supabase
  redirect("/login?message=" + encodeURIComponent("Check your email to confirm your account, then log in."));
}
export async function logout() { await serverClient().auth.signOut(); redirect("/"); }
export async function forgotPassword(formData) {
  const email = s(formData, "email");
  if (!emailOk(email)) redirect("/forgot-password?error=" + encodeURIComponent("Enter a valid email address."));
  await serverClient().auth.resetPasswordForEmail(email, { redirectTo: `${site()}/auth/callback?next=/reset-password` });
  // Same message whether or not the email exists, so accounts cannot be probed
  redirect("/forgot-password?message=" + encodeURIComponent("If an account exists for that email, a reset link is on its way."));
}
export async function resetPassword(formData) {
  const pw = String(formData.get("password") || "");
  const back = (m) => redirect(`/reset-password?error=${encodeURIComponent(m)}`);
  if (pw.length < 8) back("Password must be at least 8 characters.");
  if (pw !== String(formData.get("confirm") || "")) back("Passwords do not match.");
  const supabase = serverClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/forgot-password?error=" + encodeURIComponent("Your reset link has expired. Request a new one."));
  const { error } = await supabase.auth.updateUser({ password: pw });
  if (error) back(error.message);
  redirect("/account/profile?message=" + encodeURIComponent("Password updated."));
}
