"use client";
import { useFormState } from "react-dom";
import { sendContact } from "./actions";
export default function ContactForm() {
  const [s, action] = useFormState(sendContact, null);
  return (
    <div className="mx-auto max-w-lg px-4 py-14">
      <h1 className="font-display text-3xl mb-2">Contact us</h1>
      <p className="text-sm text-neutral-500 mb-6">Questions about an order, sizing or a product? Send us a message.</p>
      {s?.ok ? <p role="status" className="border border-ink text-sm p-4">Thank you. Your message was sent and we will reply by email.</p> : (
        <form action={action} className="grid gap-3">
          <input name="name" required minLength={2} maxLength={80} placeholder="Your name" aria-label="Name" autoComplete="name" className="field" />
          <input name="email" type="email" required maxLength={120} placeholder="Email" aria-label="Email" autoComplete="email" className="field" />
          <input name="subject" required minLength={3} maxLength={120} placeholder="Subject" aria-label="Subject" className="field" />
          <textarea name="message" required minLength={10} maxLength={2000} rows={6} placeholder="Message" aria-label="Message" className="field" />
          <input name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />
          {s?.error && <p role="alert" className="border border-sale text-sale text-sm p-3">{s.error}</p>}
          <button className="btn">Send message</button>
        </form>)}
    </div>
  );
}
