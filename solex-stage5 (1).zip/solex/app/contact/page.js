import ContactForm from "./ContactForm"; export const metadata = { title: "Contact | SOLEX" }; export default function Contact() { return <ContactForm />; }
