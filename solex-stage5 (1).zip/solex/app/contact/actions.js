"use server";
import { adminClient } from "@/lib/supabase-admin";
import { serverClient } from "@/lib/supabase-server";
import { limited, ipKey } from "@/lib/ratelimit";
import { sendEmail, esc } from "@/lib/email";
export async function sendContact(_prev, fd) {
  if (String(fd.get("website") || "")) return { ok: true }; // honeypot: bots fill hidden fields; pretend success
  const name = String(fd.get("name") || "").trim(), email = String(fd.get("email") || "").trim().toLowerCase(), subject = String(fd.get("subject") || "").trim(), message = String(fd.get("message") || "").trim();
  if (name.length < 2 || name.length > 80) return { error: "Please enter your name." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120) return { error: "Enter a valid email address." };
  if (subject.length < 3 || subject.length > 120) return { error: "Please add a short subject." };
  if (message.length < 10 || message.length > 2000) return { error: "Your message must be 10 to 2000 characters." };
  const db = adminClient();
  if (!db) return { error: "The contact form is not configured yet." };
  if ((await limited(db, "contact-ip:" + ipKey(), 5, 60)) || (await limited(db, "contact:" + email, 3, 60))) return { error: "Too many messages. Please try again later." };
  let userId = null; try { const { data: { user } } = await serverClient().auth.getUser(); userId = user?.id || null; } catch {}
  const { error } = await db.from("contact_messages").insert({ name, email, subject, message, user_id: userId });
  if (error) return { error: "Could not send your message. Please try again." };
  await sendEmail({ to: process.env.CONTACT_TO_EMAIL, replyTo: email, subject: `SOLEX contact: ${subject}`, html: `<p><b>${esc(name)}</b> (${esc(email)})</p><p style="white-space:pre-wrap">${esc(message)}</p>` });
  return { ok: true };
}
