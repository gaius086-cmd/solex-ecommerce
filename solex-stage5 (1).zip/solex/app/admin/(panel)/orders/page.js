import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
import { naira } from "@/lib/supabase";
import { STATUSES } from "@/lib/util";
import { sendEmail, statusEmail, NOTIFY_STATUSES } from "@/lib/email";
async function setStatus(formData) {
  "use server";
  const { supabase } = await requireAdmin();
  const id = String(formData.get("id")), status = String(formData.get("status"));
  if (!STATUSES.includes(status)) return;
  const courier = String(formData.get("courier") || "").trim().slice(0, 80) || null, tracking = String(formData.get("tracking_number") || "").trim().slice(0, 80) || null;
  const { data: before } = await supabase.from("orders").select("status").eq("id", id).single();
  const { data: o, error } = await supabase.from("orders").update({ status, courier, tracking_number: tracking }).eq("id", id).select("order_number,email,customer_name,courier,tracking_number").single();
  // Notification email only when the status really changed (and email is configured). Failures never block the update.
  if (!error && before && before.status !== status && NOTIFY_STATUSES.includes(status) && o?.email) { const m = statusEmail(o, status); await sendEmail({ to: o.email, ...m }); }
  revalidatePath("/admin/orders"); revalidatePath("/admin");
}
export default async function Orders({ searchParams }) {
  const { supabase } = await requireAdmin();
  let q = supabase.from("orders").select("id,order_number,status,total,subtotal,shipping_fee,discount_code,discount_amount,courier,tracking_number,created_at,email,customer_name,phone,shipping_address,stock_issue,user_id,order_items(name,size,color,qty,unit_price),payments(reference,status)").order("created_at", { ascending: false }).limit(100);
  if (searchParams.status && STATUSES.includes(searchParams.status)) q = q.eq("status", searchParams.status);
  const { data, error } = await q;
  return (
    <>
      <h1 className="font-display text-3xl mb-4">Orders</h1>
      <div className="flex flex-wrap gap-3 text-sm mb-6"><a href="/admin/orders" className="underline">All</a>{STATUSES.map((s) => <a key={s} href={`/admin/orders?status=${s}`} className="underline">{s}</a>)}</div>
      {error && <p role="alert" className="text-sale text-sm">{error.message}</p>}
      {!data?.length ? <p className="text-sm text-neutral-500 border border-line p-6">No orders here yet.</p> : (
        <ul className="grid gap-4">{data.map((o) => { const a = o.shipping_address || {}; return (
          <li key={o.id} className="border border-line p-4 text-sm">
            <div className="flex flex-wrap justify-between gap-2"><p className="font-semibold">{o.order_number || o.id.slice(0, 8)} · {naira(o.total)}</p><p className="text-neutral-500">{new Date(o.created_at).toLocaleString("en-NG")}</p></div>
            {o.stock_issue && <p role="alert" className="mt-2 border border-sale text-sale p-2">Paid, but stock ran out before payment was confirmed. Contact the customer or refund in Paystack.</p>}
            <p className="mt-1">{o.customer_name || "Customer"} · {o.email || "—"} · {o.phone || "—"} {o.user_id ? "" : "(guest or deleted account)"}</p>
            <p className="text-neutral-600">{a.line1 ? `${a.line1}${a.line2 ? `, ${a.line2}` : ""}, ${a.city}, ${a.state}` : "Address removed"}</p>
            <ul className="mt-2 text-neutral-700">{o.order_items?.map((i, n) => <li key={n}>{i.qty} × {i.name} (size {i.size}{i.color ? `, ${i.color}` : ""}) · {naira(i.unit_price)}</li>)}</ul>
            <p className="text-neutral-500 mt-1">Subtotal {naira(o.subtotal)}{o.discount_amount > 0 ? ` · Discount ${o.discount_code} −${naira(o.discount_amount)}` : ""} · Delivery {naira(o.shipping_fee)} · Payment: {o.payments?.[0]?.status || "none"}</p>
            <form action={setStatus} className="mt-3 flex flex-wrap gap-2"><input type="hidden" name="id" value={o.id} />
              <select name="status" defaultValue={o.status} aria-label="Status" className="border border-line px-2 py-1">{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
              <input name="courier" defaultValue={o.courier || ""} placeholder="Courier" aria-label="Courier" className="border border-line px-2 py-1 w-32" />
              <input name="tracking_number" defaultValue={o.tracking_number || ""} placeholder="Tracking no." aria-label="Tracking number" className="border border-line px-2 py-1 w-36" />
              <button className="btn !py-1 !px-3">Update</button></form>
          </li>); })}</ul>
      )}
    </>
  );
}
