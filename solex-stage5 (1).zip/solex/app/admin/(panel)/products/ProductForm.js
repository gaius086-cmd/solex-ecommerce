import { saveProduct, deleteImage } from "./actions";
import { requireAdmin } from "@/lib/auth";
export default async function ProductForm({ product, error, saved }) {
  const { supabase } = await requireAdmin();
  const [{ data: brands }, { data: cats }] = await Promise.all([supabase.from("brands").select("name").order("name"), supabase.from("categories").select("name").order("name")]);
  const p = product || {};
  const f = "border border-line px-3 py-2 text-sm w-full";
  const sizes = (p.product_sizes || []).sort((a, b) => a.size - b.size).map((s) => `${s.size}:${s.stock}`).join(", ");
  const colors = (p.product_colors || []).map((c) => (c.hex ? `${c.name}:${c.hex}` : c.name)).join(", ");
  const L = ({ t, children }) => <label className="grid gap-1 text-xs font-semibold">{t}{children}</label>;
  return (
    <>
      {error && <p role="alert" className="border border-sale text-sale text-sm p-3 mb-4">{error}</p>}
      {saved && <p role="status" className="border border-ink text-sm p-3 mb-4">Saved. The change is live on the store.</p>}
      <form action={saveProduct} className="grid md:grid-cols-2 gap-4">
        <input type="hidden" name="id" defaultValue={p.id || ""} />
        <L t="Name"><input name="name" required defaultValue={p.name} className={f} /></L>
        <L t="Gender"><select name="gender" defaultValue={p.gender || "unisex"} className={f}>{["unisex", "men", "women", "kids"].map((g) => <option key={g}>{g}</option>)}</select></L>
        <L t="Price (₦)"><input name="price" type="number" step="0.01" min="0" required defaultValue={p.price} className={f} /></L>
        <L t="Discounted price (₦, optional)"><input name="sale_price" type="number" step="0.01" min="0" defaultValue={p.sale_price ?? ""} className={f} /></L>
        <L t="Brand"><input name="brand" list="brands" required defaultValue={p.brands?.name} className={f} /></L>
        <L t="Category"><input name="category" list="cats" required defaultValue={p.categories?.name} className={f} /></L>
        <datalist id="brands">{brands?.map((b) => <option key={b.name} value={b.name} />)}</datalist>
        <datalist id="cats">{cats?.map((c) => <option key={c.name} value={c.name} />)}</datalist>
        <L t="Sizes and stock (size:stock, comma separated)"><textarea name="sizes" rows={2} placeholder="40:5, 41:3, 42:8" defaultValue={sizes} className={f} /></L>
        <L t="Colours (name:#hex, comma separated)"><textarea name="colors" rows={2} placeholder="Black:#000000, White:#ffffff" defaultValue={colors} className={f} /></L>
        <L t="Description"><textarea name="description" rows={5} defaultValue={p.description || ""} className={`${f} md:col-span-2`} /></L>
        <L t="Add images (several allowed, 5 MB each; the first is the main image)"><input name="images" type="file" multiple accept="image/*" className={f} /></L>
        <div className="flex flex-wrap gap-6 items-center text-sm">
          <label className="flex gap-2"><input type="checkbox" name="is_featured" defaultChecked={p.is_featured} /> Featured</label>
          <label className="flex gap-2"><input type="checkbox" name="is_best_seller" defaultChecked={p.is_best_seller} /> Best seller</label>
          <label className="flex gap-2"><input type="checkbox" name="is_active" defaultChecked={p.is_active ?? true} /> Visible on store</label>
        </div>
        <button className="btn md:col-span-2">{p.id ? "Save changes" : "Create product"}</button>
      </form>
      {!!p.product_images?.length && (
        <div className="mt-8"><h2 className="font-semibold mb-3 text-sm">Images</h2>
          <div className="flex flex-wrap gap-4">{[...p.product_images].sort((a, b) => a.position - b.position).map((i) => (
            <form key={i.id} action={deleteImage} className="w-28"><input type="hidden" name="image_id" value={i.id} /><input type="hidden" name="product_id" value={p.id} />
              <img src={i.url} alt="" className="h-28 w-28 object-cover bg-mist" /><button className="underline text-xs mt-1">Remove</button></form>))}</div></div>
      )}
    </>
  );
}
