import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import ProductForm from "../ProductForm";
import { deleteProduct } from "../actions";
export default async function EditProduct({ params, searchParams }) {
  const { supabase } = await requireAdmin();
  const { data: p } = await supabase.from("products").select("*,brands(name),categories(name),product_images(id,url,position),product_sizes(size,stock),product_colors(name,hex)").eq("id", params.id).maybeSingle();
  if (!p) notFound();
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Edit product</h1>
      <ProductForm product={p} error={searchParams.error} saved={searchParams.saved} />
      <form action={deleteProduct} className="mt-12 border-t border-line pt-6"><input type="hidden" name="id" value={p.id} /><button className="text-sale underline text-sm">Delete this product permanently</button></form>
    </>
  );
}
