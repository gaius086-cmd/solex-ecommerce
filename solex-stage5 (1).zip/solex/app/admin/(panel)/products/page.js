import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { naira } from "@/lib/supabase";
export default async function Products({ searchParams }) {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("products").select("id,name,price,sale_price,is_active,is_featured,is_best_seller,brands(name),product_sizes(stock)").order("created_at", { ascending: false });
  return (
    <>
      <div className="flex justify-between items-center mb-6"><h1 className="font-display text-3xl">Products</h1><Link href="/admin/products/new" className="btn">Add product</Link></div>
      {searchParams.error && <p role="alert" className="border border-sale text-sale text-sm p-3 mb-4">{searchParams.error}</p>}
      {!data?.length ? <p className="text-sm text-neutral-500 border border-line p-6">No products yet. Add your first shoe.</p> : (
        <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="text-left border-b border-line"><tr><th className="py-2">Name</th><th>Brand</th><th>Price</th><th>Stock</th><th>Status</th><th /></tr></thead>
          <tbody>{data.map((p) => (
            <tr key={p.id} className="border-b border-line"><td className="py-3 font-semibold">{p.name}</td><td>{p.brands?.name}</td><td>{naira(p.sale_price || p.price)}</td>
              <td>{p.product_sizes?.reduce((a, s) => a + s.stock, 0)}</td>
              <td>{p.is_active ? "Live" : "Hidden"}{p.is_featured ? " · Featured" : ""}{p.is_best_seller ? " · Best seller" : ""}</td>
              <td className="text-right"><Link href={`/admin/products/${p.id}`} className="underline">Edit</Link></td></tr>))}</tbody></table></div>
      )}
    </>
  );
}
