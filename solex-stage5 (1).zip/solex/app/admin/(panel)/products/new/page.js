import ProductForm from "../ProductForm";
export default function NewProduct({ searchParams }) {
  return <><h1 className="font-display text-3xl mb-6">Add product</h1><ProductForm error={searchParams.error} /></>;
}
