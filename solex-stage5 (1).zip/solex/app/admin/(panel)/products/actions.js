"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
import { slugify } from "@/lib/util";
const BUCKET = "product-images";
const fail = (id, msg) => redirect(`/admin/products/${id || "new"}?error=${encodeURIComponent(msg)}`);
const refresh = () => { ["/", "/shop", "/admin/products", "/admin/inventory"].forEach((p) => revalidatePath(p)); revalidatePath("/product/[slug]", "page"); };
function parsePairs(text, what) {
  const out = [];
  for (const part of String(text || "").split(/[\n,]+/).map((s) => s.trim()).filter(Boolean)) {
    const [a, b] = part.split(":").map((s) => s.trim());
    out.push([a, b]);
  }
  return out;
}
async function named(supabase, table, name) {
  const slug = slugify(name);
  if (!slug) return null;
  const { data, error } = await supabase.from(table).upsert({ name: name.trim(), slug }, { onConflict: "slug" }).select("id").single();
  if (error) throw new Error(error.message);
  return data.id;
}
export async function saveProduct(formData) {
  const { supabase } = await requireAdmin();
  const id = String(formData.get("id") || "") || null;
  const f = (k) => String(formData.get(k) || "").trim();
  const name = f("name"), price = Number(f("price")), sale = f("sale_price") ? Number(f("sale_price")) : null;
  if (!name) return fail(id, "Product name is required.");
  if (!Number.isFinite(price) || price < 0) return fail(id, "Enter a valid price.");
  if (sale !== null && (!Number.isFinite(sale) || sale < 0 || sale >= price)) return fail(id, "Discounted price must be lower than the price.");
  if (!f("brand") || !f("category")) return fail(id, "Brand and category are required.");
  const sizes = parsePairs(f("sizes")).map(([s, st]) => [Number(s), Number(st ?? 0)]);
  if (sizes.some(([s, st]) => !Number.isFinite(s) || s <= 0 || !Number.isInteger(st) || st < 0)) return fail(id, "Sizes must look like 40:5, 41:3 (size:stock, whole-number stock).");
  const colors = parsePairs(f("colors")).filter(([n]) => n);
  if (colors.some(([, h]) => h && !/^#[0-9a-fA-F]{6}$/.test(h))) return fail(id, "Colour codes must look like Black:#000000.");
  const files = formData.getAll("images").filter((x) => x && x.size > 0);
  for (const x of files) { if (!x.type.startsWith("image/") || x.size > 5 * 1024 * 1024) return fail(id, "Images must be image files under 5 MB each."); }
  let pid = id;
  try {
    const row = { name, description: f("description") || null, price, sale_price: sale, brand_id: await named(supabase, "brands", f("brand")), category_id: await named(supabase, "categories", f("category")),
      gender: f("gender") || "unisex", is_featured: formData.get("is_featured") === "on", is_best_seller: formData.get("is_best_seller") === "on", is_active: formData.get("is_active") === "on" };
    if (id) { const { error } = await supabase.from("products").update(row).eq("id", id); if (error) throw error; }
    else {
      let slug = slugify(name);
      const { data: clash } = await supabase.from("products").select("id").eq("slug", slug).maybeSingle();
      if (clash) slug += "-" + Math.random().toString(36).slice(2, 6);
      const { data, error } = await supabase.from("products").insert({ ...row, slug }).select("id").single(); if (error) throw error; pid = data.id;
    }
    // Sizes: upsert submitted rows, remove the rest (keeps ids stable)
    await supabase.from("product_sizes").delete().eq("product_id", pid).not("size", "in", `(${sizes.map(([s]) => s).join(",") || "-1"})`);
    if (sizes.length) { const { error } = await supabase.from("product_sizes").upsert(sizes.map(([size, stock]) => ({ product_id: pid, size, stock })), { onConflict: "product_id,size" }); if (error) throw error; }
    await supabase.from("product_colors").delete().eq("product_id", pid);
    if (colors.length) { const { error } = await supabase.from("product_colors").insert(colors.map(([n, h]) => ({ product_id: pid, name: n, hex: h || null }))); if (error) throw error; }
    if (files.length) {
      const { count } = await supabase.from("product_images").select("id", { count: "exact", head: true }).eq("product_id", pid);
      let pos = count || 0;
      for (const file of files) {
        const path = `${pid}/${crypto.randomUUID()}.${(file.name.split(".").pop() || "jpg").toLowerCase()}`;
        const up = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type });
        if (up.error) throw up.error;
        const { error } = await supabase.from("product_images").insert({ product_id: pid, url: supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl, storage_path: path, position: pos++ });
        if (error) throw error;
      }
    }
  } catch (e) { return fail(pid, e.message || "Could not save the product."); }
  refresh();
  redirect(`/admin/products/${pid}?saved=1`);
}
export async function deleteImage(formData) {
  const { supabase } = await requireAdmin();
  const imgId = String(formData.get("image_id")), pid = String(formData.get("product_id"));
  const { data } = await supabase.from("product_images").select("storage_path").eq("id", imgId).maybeSingle();
  if (data?.storage_path) await supabase.storage.from(BUCKET).remove([data.storage_path]);
  await supabase.from("product_images").delete().eq("id", imgId);
  refresh(); redirect(`/admin/products/${pid}`);
}
export async function deleteProduct(formData) {
  const { supabase } = await requireAdmin();
  const id = String(formData.get("id"));
  const { data: imgs } = await supabase.from("product_images").select("storage_path").eq("product_id", id);
  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) redirect(`/admin/products?error=${encodeURIComponent("This product is in past orders and cannot be deleted. Untick 'Visible on store' instead.")}`);
  const paths = (imgs || []).map((i) => i.storage_path).filter(Boolean);
  if (paths.length) await supabase.storage.from(BUCKET).remove(paths);
  refresh(); redirect("/admin/products");
}
