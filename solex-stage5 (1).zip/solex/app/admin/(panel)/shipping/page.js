import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
import { naira } from "@/lib/supabase";
import { STATES } from "@/lib/checkout";
async function saveRate(fd) {
  "use server";
  const { supabase } = await requireAdmin();
  const state = String(fd.get("state")), fee = Number(fd.get("fee"));
  if ((state !== "DEFAULT" && !STATES.includes(state)) || !Number.isFinite(fee) || fee < 0) return;
  await supabase.from("shipping_rates").upsert({ state, fee }, { onConflict: "state" }); revalidatePath("/admin/shipping");
}
async function delRate(fd) {
  "use server";
  const { supabase } = await requireAdmin(); const state = String(fd.get("state"));
  if (state !== "DEFAULT") await supabase.from("shipping_rates").delete().eq("state", state); revalidatePath("/admin/shipping");
}
export default async function Shipping() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("shipping_rates").select("*").order("state");
  return (
    <>
      <h1 className="font-display text-3xl mb-2">Shipping fees</h1>
      <p className="text-sm text-neutral-500 mb-6">The DEFAULT fee applies to any state without its own row. Customers see these fees at checkout.</p>
      <ul className="divide-y divide-line border border-line mb-8">{data?.map((r) => (
        <li key={r.state} className="p-3 flex items-center gap-3 text-sm"><span className="flex-1 font-semibold">{r.state}</span><span className="text-neutral-500">{naira(r.fee)}</span>
          <form action={saveRate} className="flex gap-2"><input type="hidden" name="state" value={r.state} /><input name="fee" type="number" min="0" step="0.01" defaultValue={r.fee} aria-label="Fee" className="border border-line w-24 px-2 py-1" /><button className="btn !py-1 !px-3">Save</button></form>
          {r.state !== "DEFAULT" && <form action={delRate}><input type="hidden" name="state" value={r.state} /><button className="underline text-sale text-xs">Remove</button></form>}</li>))}</ul>
      <form action={saveRate} className="flex flex-wrap gap-2 text-sm"><select name="state" className="border border-line px-2 py-2">{STATES.map((s) => <option key={s}>{s}</option>)}</select><input name="fee" type="number" min="0" step="0.01" required placeholder="Fee (₦)" className="border border-line px-2 py-2 w-32" /><button className="btn !py-2">Add or update state</button></form>
    </>
  );
}
