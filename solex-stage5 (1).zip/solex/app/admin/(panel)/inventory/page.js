import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
async function updateStock(formData) {
  "use server";
  const { supabase } = await requireAdmin();
  const stock = Number(formData.get("stock"));
  if (!Number.isInteger(stock) || stock < 0) return;
  await supabase.from("product_sizes").update({ stock }).eq("id", String(formData.get("id")));
  revalidatePath("/admin/inventory"); revalidatePath("/shop"); revalidatePath("/product/[slug]", "page");
}
export default async function Inventory() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("product_sizes").select("id,size,stock,products(name)").order("stock").limit(300);
  return (
    <>
      <h1 className="font-display text-3xl mb-2">Inventory</h1>
      <p className="text-sm text-neutral-500 mb-6">Lowest stock first. Change a number and press Update.</p>
      {!data?.length ? <p className="text-sm text-neutral-500 border border-line p-6">No sizes yet. Add sizes when you create a product.</p> : (
        <ul className="divide-y divide-line border border-line">{data.map((s) => (
          <li key={s.id} className="p-3 flex items-center gap-4 text-sm"><span className="flex-1">{s.products?.name} · size {s.size}</span>
            {s.stock <= 3 && <span className="text-sale text-xs font-semibold">{s.stock === 0 ? "Out of stock" : "Low"}</span>}
            <form action={updateStock} className="flex gap-2"><input type="hidden" name="id" value={s.id} /><input name="stock" type="number" min="0" defaultValue={s.stock} aria-label="Stock" className="border border-line w-20 px-2 py-1" /><button className="btn !py-1 !px-3">Update</button></form></li>))}</ul>
      )}
    </>
  );
}
