import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { naira } from "@/lib/supabase";
export default async function Dashboard() {
  const { supabase } = await requireAdmin();
  const cnt = (t, f) => { let q = supabase.from(t).select("id", { count: "exact", head: true }); return f ? f(q) : q; };
  const [prods, ords, custs, pending, sold, low] = await Promise.all([
    cnt("products"), cnt("orders"), cnt("profiles", (q) => q.eq("role", "customer")), cnt("orders", (q) => q.in("status", ["pending", "paid", "processing"])),
    supabase.from("orders").select("total,created_at").in("status", ["paid", "processing", "shipped", "delivered"]),
    supabase.from("product_sizes").select("size,stock,products(name)").lte("stock", 3).order("stock").limit(8),
  ]);
  const rows = sold.data || [];
  const revenue = rows.reduce((a, r) => a + Number(r.total), 0);
  const month = new Date().toISOString().slice(0, 7);
  const monthRev = rows.filter((r) => r.created_at.startsWith(month)).reduce((a, r) => a + Number(r.total), 0);
  const stats = [["Products", prods.count ?? 0], ["Customers", custs.count ?? 0], ["All orders", ords.count ?? 0], ["Open orders", pending.count ?? 0], ["Sales (paid orders)", naira(revenue)], ["Sales this month", naira(monthRev)]];
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Dashboard</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-px bg-line border border-line">{stats.map(([l, v]) => <div key={l} className="bg-paper p-5"><p className="text-xs text-neutral-500">{l}</p><p className="text-2xl font-semibold mt-1">{v}</p></div>)}</div>
      <h2 className="font-semibold mt-10 mb-3">Low stock (3 or fewer)</h2>
      {low.data?.length ? <ul className="text-sm divide-y divide-line border border-line">{low.data.map((s, i) => <li key={i} className="p-3 flex justify-between"><span>{s.products?.name} · size {s.size}</span><span className={s.stock === 0 ? "text-sale font-semibold" : ""}>{s.stock} left</span></li>)}</ul> : <p className="text-sm text-neutral-500">Nothing is running low.</p>}
      <p className="mt-8"><Link href="/admin/products/new" className="btn">Add product</Link></p>
    </>
  );
}
