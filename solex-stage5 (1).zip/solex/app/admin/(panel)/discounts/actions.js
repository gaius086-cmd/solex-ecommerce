"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
const num = (v) => (String(v ?? "").trim() === "" ? null : Number(v));
// Form times are Nigeria time (WAT, UTC+1)
const when = (v) => (String(v || "").trim() ? new Date(`${String(v).trim()}:00+01:00`).toISOString() : null);
export async function saveDiscount(fd) {
  const { supabase } = await requireAdmin();
  const id = String(fd.get("id") || "") || null;
  const back = (e) => redirect(`/admin/discounts?error=${encodeURIComponent(e)}${id ? `&edit=${id}` : ""}`);
  const code = String(fd.get("code") || "").trim().toUpperCase(), type = String(fd.get("type"));
  if (!/^[A-Z0-9_-]{3,24}$/.test(code)) back("Code must be 3-24 letters, numbers, - or _.");
  const percent = num(fd.get("percent")), amount = num(fd.get("amount")), min = num(fd.get("min_subtotal")) ?? 0, limit = num(fd.get("usage_limit"));
  if (type === "percent" ? !(percent >= 1 && percent <= 100) : !(amount > 0)) back(type === "percent" ? "Percentage must be between 1 and 100." : "Enter a fixed amount above 0.");
  if (!(min >= 0) || (limit !== null && !(Number.isInteger(limit) && limit > 0))) back("Check the minimum spend and usage limit.");
  const starts = when(fd.get("starts_at")), expires = when(fd.get("expires_at"));
  if (Number.isNaN(Date.parse(starts || "2000-01-01")) || Number.isNaN(Date.parse(expires || "2000-01-01"))) back("Invalid date.");
  if (starts && expires && new Date(expires) <= new Date(starts)) back("Expiry must be after the start date.");
  const row = { code, description: String(fd.get("description") || "").trim() || null, type, percent: type === "percent" ? percent : null, amount: type === "fixed" ? amount : null, min_subtotal: min, usage_limit: limit, starts_at: starts, expires_at: expires, is_public: fd.get("is_public") === "on", active: fd.get("active") === "on" };
  const { error } = id ? await supabase.from("discounts").update(row).eq("id", id) : await supabase.from("discounts").insert(row);
  if (error) back(error.code === "23505" ? "That code already exists." : "Could not save the discount.");
  revalidatePath("/admin/discounts"); revalidatePath("/"); redirect("/admin/discounts?saved=1");
}
export async function toggleDiscount(fd) {
  const { supabase } = await requireAdmin();
  await supabase.from("discounts").update({ active: String(fd.get("active")) === "true" }).eq("id", String(fd.get("id")));
  revalidatePath("/admin/discounts"); revalidatePath("/"); redirect("/admin/discounts");
}
