import { requireAdmin } from "@/lib/auth";
import { naira } from "@/lib/supabase";
import { saveDiscount, toggleDiscount } from "./actions";
const lagosInput = (iso) => (iso ? new Date(iso).toLocaleString("sv-SE", { timeZone: "Africa/Lagos" }).replace(" ", "T").slice(0, 16) : "");
const show = (iso) => (iso ? new Date(iso).toLocaleString("en-NG", { timeZone: "Africa/Lagos", dateStyle: "medium", timeStyle: "short" }) : "—");
export default async function Discounts({ searchParams }) {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("discounts").select("*").order("created_at", { ascending: false });
  const e = data?.find((d) => d.id === searchParams.edit);
  const L = ({ t, children }) => <label className="grid gap-1 text-xs font-semibold">{t}{children}</label>;
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Discount codes</h1>
      {searchParams.error && <p role="alert" className="border border-sale text-sale text-sm p-3 mb-4">{searchParams.error}</p>}
      {searchParams.saved && <p role="status" className="border border-ink text-sm p-3 mb-4">Saved.</p>}
      {!data?.length ? <p className="text-sm text-neutral-500 border border-line p-5 mb-8">No discount codes yet.</p> : (
        <div className="overflow-x-auto mb-10"><table className="w-full text-sm"><thead className="text-left border-b border-line"><tr><th className="py-2">Code</th><th>Value</th><th>Used</th><th>Starts</th><th>Expires</th><th>Status</th><th /></tr></thead>
          <tbody>{data.map((d) => (
            <tr key={d.id} className="border-b border-line"><td className="py-3 font-semibold">{d.code}{d.is_public ? " · public" : ""}</td>
              <td>{d.type === "percent" ? `${d.percent}%` : naira(d.amount)}{d.min_subtotal > 0 ? ` (min ${naira(d.min_subtotal)})` : ""}</td>
              <td>{d.used_count}{d.usage_limit ? ` / ${d.usage_limit}` : ""}</td><td>{show(d.starts_at)}</td><td>{show(d.expires_at)}</td><td>{d.active ? "Active" : "Off"}</td>
              <td className="text-right whitespace-nowrap"><a href={`/admin/discounts?edit=${d.id}`} className="underline mr-3">Edit</a>
                <form action={toggleDiscount} className="inline"><input type="hidden" name="id" value={d.id} /><input type="hidden" name="active" value={String(!d.active)} /><button className="underline">{d.active ? "Deactivate" : "Activate"}</button></form></td></tr>))}</tbody></table></div>)}
      <h2 className="font-semibold mb-3">{e ? `Edit ${e.code}` : "New discount"}</h2>
      <form action={saveDiscount} key={e?.id || "new"} className="grid sm:grid-cols-2 gap-4 max-w-2xl">
        <input type="hidden" name="id" defaultValue={e?.id || ""} />
        <L t="Code"><input name="code" required defaultValue={e?.code} className="field uppercase" placeholder="WELCOME10" /></L>
        <L t="Type"><select name="type" defaultValue={e?.type || "percent"} className="field"><option value="percent">Percentage</option><option value="fixed">Fixed amount (₦)</option></select></L>
        <L t="Percentage (if percentage)"><input name="percent" type="number" min="1" max="100" defaultValue={e?.percent ?? ""} className="field" /></L>
        <L t="Amount ₦ (if fixed)"><input name="amount" type="number" min="1" step="0.01" defaultValue={e?.amount ?? ""} className="field" /></L>
        <L t="Minimum spend ₦"><input name="min_subtotal" type="number" min="0" step="0.01" defaultValue={e?.min_subtotal ?? 0} className="field" /></L>
        <L t="Usage limit (blank = unlimited)"><input name="usage_limit" type="number" min="1" defaultValue={e?.usage_limit ?? ""} className="field" /></L>
        <L t="Starts (Nigeria time, optional)"><input name="starts_at" type="datetime-local" defaultValue={lagosInput(e?.starts_at)} className="field" /></L>
        <L t="Expires (Nigeria time, optional)"><input name="expires_at" type="datetime-local" defaultValue={lagosInput(e?.expires_at)} className="field" /></L>
        <L t="Description (shown on homepage if public)"><input name="description" defaultValue={e?.description || ""} className="field sm:col-span-2" /></L>
        <label className="flex gap-2 text-sm"><input type="checkbox" name="active" defaultChecked={e?.active ?? true} /> Active</label>
        <label className="flex gap-2 text-sm"><input type="checkbox" name="is_public" defaultChecked={e?.is_public} /> Show as homepage offer</label>
        <div className="sm:col-span-2 flex gap-3"><button className="btn">{e ? "Save changes" : "Create discount"}</button>{e && <a href="/admin/discounts" className="btn-out">Cancel</a>}</div>
      </form>
    </>
  );
}
