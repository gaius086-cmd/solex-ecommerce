import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
async function mark(fd) {
  "use server";
  const { supabase } = await requireAdmin();
  const status = String(fd.get("status")) === "handled" ? "handled" : "new";
  await supabase.from("contact_messages").update({ status }).eq("id", String(fd.get("id"))); revalidatePath("/admin/messages");
}
export default async function Messages() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("contact_messages").select("*").order("created_at", { ascending: false }).limit(100);
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Messages</h1>
      {!data?.length ? <p className="text-sm text-neutral-500 border border-line p-6">No messages yet.</p> : (
        <ul className="grid gap-4">{data.map((m) => (
          <li key={m.id} className="border border-line p-4 text-sm">
            <div className="flex flex-wrap justify-between gap-2"><p className="font-semibold">{m.subject}</p><p className="text-neutral-500">{new Date(m.created_at).toLocaleString("en-NG")}</p></div>
            <p className="mt-1">{m.name} · <a href={`mailto:${m.email}`} className="underline">{m.email}</a>{m.user_id ? " (customer)" : ""}</p>
            <p className="mt-2 whitespace-pre-wrap">{m.message}</p>
            <form action={mark} className="mt-3 flex gap-3 items-center"><input type="hidden" name="id" value={m.id} /><input type="hidden" name="status" value={m.status === "new" ? "handled" : "new"} />
              <span className={m.status === "new" ? "font-semibold" : "text-neutral-500"}>{m.status === "new" ? "New" : "Handled"}</span><button className="underline">{m.status === "new" ? "Mark handled" : "Mark new"}</button></form>
          </li>))}</ul>)}
    </>
  );
}
