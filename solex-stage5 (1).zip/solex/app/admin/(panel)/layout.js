import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { logout } from "../login/actions";
export const dynamic = "force-dynamic";
export default async function PanelLayout({ children }) {
  const { user } = await requireAdmin();
  const links = [["Dashboard", "/admin"], ["Products", "/admin/products"], ["Inventory", "/admin/inventory"], ["Orders", "/admin/orders"], ["Customers", "/admin/customers"], ["Shipping", "/admin/shipping"], ["Discounts", "/admin/discounts"], ["Messages", "/admin/messages"]];
  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-line pb-4 mb-8 text-sm">
        {links.map(([l, h]) => <Link key={h} href={h} className="font-semibold hover:underline underline-offset-4">{l}</Link>)}
        <span className="ml-auto text-neutral-500">{user.email}</span>
        <form action={logout}><button className="underline">Log out</button></form>
      </div>
      {children}
    </div>
  );
}
