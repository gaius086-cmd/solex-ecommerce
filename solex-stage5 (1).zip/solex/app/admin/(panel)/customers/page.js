import { requireAdmin } from "@/lib/auth";
import { naira } from "@/lib/supabase";
export default async function Customers() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("profiles").select("id,full_name,email,phone,role,orders(total,status)").eq("role", "customer").order("full_name");
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Customers</h1>
      {!data?.length ? <p className="text-sm text-neutral-500 border border-line p-6">No customers yet. They appear after they register (customer sign-up arrives in a later stage).</p> : (
        <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="text-left border-b border-line"><tr><th className="py-2">Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Paid total</th></tr></thead>
          <tbody>{data.map((c) => { const paid = (c.orders || []).filter((o) => ["paid", "processing", "shipped", "delivered"].includes(o.status)); return (
            <tr key={c.id} className="border-b border-line"><td className="py-3">{c.full_name || "—"}</td><td>{c.email}</td><td>{c.phone || "—"}</td><td>{c.orders?.length || 0}</td><td>{naira(paid.reduce((a, o) => a + Number(o.total), 0))}</td></tr>); })}</tbody></table></div>
      )}
    </>
  );
}
