import { login } from "./actions";
const msgs = { invalid: "Email or password is incorrect.", forbidden: "This account does not have admin access.", config: "Supabase is not configured. Add your keys to .env.local." };
export default function Login({ searchParams }) {
  return (
    <div className="mx-auto max-w-sm px-4 py-20">
      <h1 className="font-display text-3xl mb-6">Admin log in</h1>
      {searchParams.error && <p role="alert" className="border border-sale text-sale text-sm p-3 mb-4">{msgs[searchParams.error] || "Could not log in."}</p>}
      <form action={login} className="grid gap-3">
        <input name="email" type="email" required placeholder="Email" aria-label="Email" autoComplete="email" className="border border-line px-3 py-2 text-sm" />
        <input name="password" type="password" required placeholder="Password" aria-label="Password" autoComplete="current-password" className="border border-line px-3 py-2 text-sm" />
        <button className="btn">Log in</button>
      </form>
    </div>
  );
}
