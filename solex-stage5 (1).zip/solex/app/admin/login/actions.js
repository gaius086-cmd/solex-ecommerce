"use server";
import { redirect } from "next/navigation";
import { serverClient } from "@/lib/supabase-server";
export async function login(formData) {
  const supabase = serverClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email: String(formData.get("email") || "").trim(), password: String(formData.get("password") || "") });
  if (error) redirect("/admin/login?error=invalid");
  const { data: p } = await supabase.from("profiles").select("role").eq("id", data.user.id).maybeSingle();
  if (p?.role !== "admin") { await supabase.auth.signOut(); redirect("/admin/login?error=forbidden"); }
  redirect("/admin");
}
export async function logout() { await serverClient().auth.signOut(); redirect("/admin/login"); }
