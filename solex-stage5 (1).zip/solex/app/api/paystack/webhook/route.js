import { validSignature, confirmPayment } from "@/lib/paystack";
export const runtime = "nodejs";
export async function POST(request) {
  const raw = await request.text(); // raw body is required for the signature check
  if (!validSignature(raw, request.headers.get("x-paystack-signature"))) return new Response("invalid signature", { status: 401 });
  let event; try { event = JSON.parse(raw); } catch { return new Response("bad json", { status: 400 }); }
  if (event.event === "charge.success" && event.data?.reference) {
    // The webhook body is never trusted for the amount: the transaction is re-verified with Paystack, then processed idempotently.
    try { await confirmPayment(String(event.data.reference)); } catch (e) { console.error("webhook error", e.message); return new Response("retry", { status: 500 }); }
  }
  return new Response("ok");
}
