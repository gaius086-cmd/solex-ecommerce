"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { useCart } from "@/components/CartProvider";
import { naira } from "@/lib/supabase";
import { quoteCheckout, startCheckout } from "./actions";
export default function CheckoutForm({ email, loggedIn, profile, addresses, states }) {
  const { items, ready } = useCart();
  const def = addresses.find((a) => a.is_default) || addresses[0];
  const [f, setF] = useState({ email, name: def?.full_name || profile?.full_name || "", phone: def?.phone || profile?.phone || "", line1: def?.line1 || "", line2: def?.line2 || "", city: def?.city || "", state: def?.state || "", postal_code: def?.postal_code || "" });
  const [q, setQ] = useState(null), [err, setErr] = useState(""), [busy, setBusy] = useState(false);
  const [codeIn, setCodeIn] = useState(""), [code, setCode] = useState("");
  const key = useRef(crypto.randomUUID());
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const min = items.map(({ id, size, color, qty }) => ({ id, size, color, qty }));
  useEffect(() => {
    if (!ready || !items.length) return;
    key.current = crypto.randomUUID(); // new cart or state = new checkout attempt
    quoteCheckout({ items: min, state: f.state, code }).then(setQ).catch(() => setErr("Could not load your order summary."));
  }, [ready, items, f.state, code]);
  const pick = (id) => { const a = addresses.find((x) => x.id === id); if (a) setF({ ...f, name: a.full_name, phone: a.phone, line1: a.line1, line2: a.line2 || "", city: a.city, state: a.state, postal_code: a.postal_code || "" }); };
  async function submit(e) {
    e.preventDefault(); if (busy) return; setBusy(true); setErr("");
    try { const r = await startCheckout({ items: min, code, ...f, idempotencyKey: key.current }); if (r.url) { window.location.href = r.url; return; } setErr(r.error || "Something went wrong."); } catch { setErr("Something went wrong. Please try again."); }
    setBusy(false);
  }
  if (!ready) return <p className="p-10 text-sm">Loading…</p>;
  if (!items.length) return <div className="mx-auto max-w-3xl px-4 py-20 text-center"><h1 className="font-display text-3xl">Your cart is empty</h1><Link href="/shop" className="btn mt-6">Browse shoes</Link></div>;
  const L = ({ t, n, ...p }) => <label className="grid gap-1 text-xs font-semibold">{t}<input name={n} value={f[n]} onChange={set(n)} className="field" {...p} /></label>;
  const ok = q && !q.issues.length && !q.error && !q.discountError && q.total !== null;
  return (
    <div className="mx-auto max-w-5xl px-4 py-8 grid md:grid-cols-[1fr_380px] gap-10">
      <form onSubmit={submit} className="grid gap-4 order-2 md:order-1 content-start">
        <h1 className="font-display text-3xl">Checkout</h1>
        {!loggedIn && <p className="text-sm border border-line p-3">Checking out as a guest. <Link href="/login?next=/checkout" className="underline">Log in</Link> to use saved addresses and see your order history.</p>}
        {addresses.length > 0 && <label className="grid gap-1 text-xs font-semibold">Saved address<select onChange={(e) => pick(e.target.value)} defaultValue={def?.id} className="field">{addresses.map((a) => <option key={a.id} value={a.id}>{a.label || a.line1}</option>)}</select></label>}
        <L t="Email" n="email" type="email" required readOnly={loggedIn} autoComplete="email" />
        <div className="grid sm:grid-cols-2 gap-4"><L t="Full name" n="name" required autoComplete="name" /><L t="Phone" n="phone" type="tel" required autoComplete="tel" /></div>
        <L t="Address line 1" n="line1" required autoComplete="address-line1" /><L t="Address line 2 (optional)" n="line2" />
        <div className="grid sm:grid-cols-2 gap-4"><L t="City" n="city" required autoComplete="address-level2" />
          <label className="grid gap-1 text-xs font-semibold">State<select value={f.state} onChange={set("state")} required className="field"><option value="">Select state</option>{states.map((s) => <option key={s}>{s}</option>)}</select></label></div>
        <L t="Postal code (optional)" n="postal_code" />
        {err && <p role="alert" className="border border-sale text-sale text-sm p-3">{err}</p>}
        <button className="btn" disabled={busy || !ok}>{busy ? "Redirecting to Paystack…" : ok ? `Pay ${naira(q.total)}` : "Pay"}</button>
        <p className="text-xs text-neutral-500">You will pay on Paystack's secure page. Your order is confirmed only after we verify the payment.</p>
      </form>
      <aside className="order-1 md:order-2 border border-line p-4 h-fit text-sm" aria-label="Order summary">
        <h2 className="font-semibold mb-3">Order summary</h2>
        {!q ? <p>Checking prices and stock…</p> : <>
          {q.issues.length > 0 && <ul role="alert" className="text-sale mb-3 grid gap-1">{q.issues.map((m) => <li key={m}>{m}</li>)}<li><Link href="/cart" className="underline">Edit cart</Link></li></ul>}
          <ul className="grid gap-3">{q.lines.map((l) => <li key={`${l.id}${l.size}${l.color}`} className="flex gap-3"><div className="h-14 w-14 bg-mist shrink-0">{l.image && <img src={l.image} alt="" className="h-full w-full object-cover" />}</div><div className="flex-1"><p className="font-semibold">{l.name}</p><p className="text-neutral-500">Size {l.size}{l.color ? ` · ${l.color}` : ""} · Qty {l.qty}</p></div><p>{naira(l.total)}</p></li>)}</ul>
          <form onSubmit={(e) => { e.preventDefault(); setCode(codeIn.trim()); }} className="mt-4 flex gap-2"><input value={codeIn} onChange={(e) => setCodeIn(e.target.value)} placeholder="Discount code" aria-label="Discount code" className="field" /><button className="btn-out !px-4" type="submit">Apply</button>{code && <button type="button" className="underline text-xs" onClick={() => { setCode(""); setCodeIn(""); }}>Remove</button>}</form>
          {q.discountError && <p role="alert" className="text-sale mt-2">{q.discountError}</p>}
          <dl className="mt-4 pt-3 border-t border-line grid gap-1"><div className="flex justify-between"><dt>Subtotal</dt><dd>{naira(q.subtotal)}</dd></div>
            {q.discount && <div className="flex justify-between"><dt>Discount ({q.discount.code})</dt><dd>−{naira(q.discount.amount)}</dd></div>}
            <div className="flex justify-between"><dt>Delivery</dt><dd>{q.shipping === null ? "Select a state" : naira(q.shipping)}</dd></div>
            <div className="flex justify-between font-semibold text-base pt-2"><dt>Total</dt><dd>{q.total === null ? "—" : naira(q.total)}</dd></div></dl>
          {q.error && <p className="text-sale mt-2">{q.error}</p>}</>}
      </aside>
    </div>
  );
}
