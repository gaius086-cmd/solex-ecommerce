"use server";
import { serverClient } from "@/lib/supabase-server";
import { adminClient } from "@/lib/supabase-admin";
import { validateCart, shippingFee, STATES } from "@/lib/checkout";
import { applyDiscount } from "@/lib/discounts";
import { limited, ipKey } from "@/lib/ratelimit";
import { initializeTransaction, paystackConfigured } from "@/lib/paystack";
import { headers } from "next/headers";
import crypto from "crypto";
const site = () => process.env.NEXT_PUBLIC_SITE_URL || headers().get("origin") || "http://localhost:3000";
const r2 = (n) => Math.round(n * 100) / 100;
export async function quoteCheckout({ items, state, code }) {
  const supabase = serverClient();
  const cart = await validateCart(supabase, items);
  let shipping = null, error = null, discount = null, discountError = null, discountRow = null;
  if (state) { if (!STATES.includes(state)) error = "Choose a valid state."; else { shipping = await shippingFee(supabase, state); if (shipping === null) error = "Delivery fees are not configured yet."; } }
  if (code && String(code).trim() && cart.lines.length) {
    const db = adminClient();
    if (db && (await limited(db, "code:" + ipKey(), 40, 15))) discountError = "Too many code attempts. Try again in a few minutes.";
    else { const d = await applyDiscount(db, code, cart.subtotal); if (d.error) discountError = d.error; else if (d.discount) { discount = { code: d.discount.code, amount: d.amount }; discountRow = d.discount; } }
  }
  const off = discount?.amount || 0;
  return { ...cart, shipping, discount, discountError, discountId: discountRow?.id || null, total: shipping === null ? null : r2(cart.subtotal - off + shipping), error };
}
export async function startCheckout({ items, state, code, email, name, phone, line1, line2, city, postal_code, idempotencyKey }) {
  if (!paystackConfigured()) return { error: "Payments are not configured yet. The store owner must add the Paystack and Supabase service keys." };
  const supabase = serverClient(), db = adminClient();
  const { data: { user } } = await supabase.auth.getUser();
  const f = { email: String(user?.email || email || "").trim().toLowerCase(), name: String(name || "").trim(), phone: String(phone || "").trim(), line1: String(line1 || "").trim(), line2: String(line2 || "").trim(), city: String(city || "").trim(), postal_code: String(postal_code || "").trim() };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) return { error: "Enter a valid email address." };
  if (!f.name || !f.line1 || !f.city) return { error: "Name, address and city are required." };
  if (!/^[+0-9 ()-]{7,20}$/.test(f.phone)) return { error: "Enter a valid phone number." };
  const key = String(idempotencyKey || "").slice(0, 64);
  if (key) {
    const { data: ex } = await db.from("orders").select("id,status,payments(reference,authorization_url,status)").eq("idempotency_key", key).maybeSingle();
    if (ex) { const p = ex.payments?.[0]; if (ex.status === "pending" && p?.authorization_url) return { url: p.authorization_url }; if (p) return { url: `${site()}/checkout/result?reference=${p.reference}` }; }
  }
  const q = await quoteCheckout({ items, state, code });
  if (q.error) return { error: q.error };
  if (q.discountError) return { error: q.discountError };
  if (q.shipping === null) return { error: "Choose your delivery state." };
  if (q.issues.length || !q.lines.length) return { error: q.issues[0] || "Your cart is empty." };
  if (q.total < 100) return { error: "This order total is too low to process." };
  const reference = "SOLEX-" + crypto.randomUUID().replace(/-/g, "").slice(0, 20);
  const { data: order, error: oErr } = await db.from("orders").insert({
    user_id: user?.id || null, status: "pending", email: f.email, customer_name: f.name, phone: f.phone, subtotal: q.subtotal, shipping_fee: q.shipping, total: q.total,
    discount_id: q.discountId, discount_code: q.discount?.code || null, discount_amount: q.discount?.amount || 0,
    shipping_address: { full_name: f.name, phone: f.phone, line1: f.line1, line2: f.line2 || null, city: f.city, state, postal_code: f.postal_code || null, country: "Nigeria" }, idempotency_key: key || null,
  }).select("id,order_number").single();
  if (oErr) return { error: "Could not create your order. Please try again." };
  const { error: iErr } = await db.from("order_items").insert(q.lines.map((l) => ({ order_id: order.id, product_id: l.id, name: l.name, size: l.size, color: l.color, qty: l.qty, unit_price: l.unit })));
  const { error: pErr } = await db.from("payments").insert({ order_id: order.id, reference, amount: q.total, status: "initialized" });
  if (iErr || pErr) { await db.from("orders").update({ status: "cancelled" }).eq("id", order.id); return { error: "Could not create your order. Please try again." }; }
  const init = await initializeTransaction({ email: f.email, amountKobo: Math.round(q.total * 100), reference, callbackUrl: `${site()}/checkout/result`, metadata: { order_id: order.id, order_number: order.order_number } });
  if (!init.ok) { await db.from("orders").update({ status: "cancelled" }).eq("id", order.id); await db.from("payments").update({ status: "failed" }).eq("reference", reference); return { error: "Could not start the payment. Please try again." }; }
  await db.from("payments").update({ authorization_url: init.data.authorization_url }).eq("reference", reference);
  return { url: init.data.authorization_url };
}
