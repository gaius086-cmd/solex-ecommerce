import Link from "next/link";
import { confirmPayment } from "@/lib/paystack";
import { adminClient } from "@/lib/supabase-admin";
import { naira } from "@/lib/supabase";
import ClearCart from "@/components/ClearCart";
export const dynamic = "force-dynamic";
export const metadata = { title: "Payment | SOLEX" };
const Box = ({ title, children }) => <div className="mx-auto max-w-lg px-4 py-16 text-center"><h1 className="font-display text-3xl mb-3">{title}</h1><div className="text-sm text-neutral-700 grid gap-3">{children}</div></div>;
export default async function Result({ searchParams }) {
  const reference = searchParams.reference || searchParams.trxref;
  if (!reference) return <Box title="No payment found"><Link href="/cart" className="btn mx-auto">Back to cart</Link></Box>;
  // The browser's redirect proves nothing. The payment is verified with Paystack on the server before anything is shown.
  const r = await confirmPayment(String(reference));
  if (r.state === "config") return <Box title="Payments not configured"><p>The store owner must add the Paystack and Supabase service keys.</p></Box>;
  if (r.state === "unknown") return <Box title="Payment not found"><p>We could not find this payment.</p><Link href="/cart" className="btn mx-auto">Back to cart</Link></Box>;
  const db = adminClient();
  const { data: o } = await db.from("orders").select("order_number,status,total,stock_issue,order_items(name,size,color,qty)").eq("id", r.orderId).single();
  if (r.state === "success") return (
    <Box title="Payment successful">
      <ClearCart />
      <p>Thank you. Your order number is <b>{o.order_number}</b>.</p>
      {o.stock_issue && <p className="border border-line p-3">One or more items sold out while you were paying. We will contact you shortly to arrange an alternative or a refund.</p>}
      <ul className="text-left border border-line p-4">{o.order_items.map((i, n) => <li key={n}>{i.qty} × {i.name} (size {i.size}{i.color ? `, ${i.color}` : ""})</li>)}<li className="font-semibold mt-2">Total paid {naira(o.total)}</li></ul>
      <p>A confirmation email is sent if email is configured for this store.</p>
      <Link href="/shop" className="btn mx-auto">Continue shopping</Link>
    </Box>);
  if (r.state === "mismatch") return <Box title="Payment needs review"><p>The amount paid did not match your order, so it was not confirmed. Contact us with order {o?.order_number}.</p></Box>;
  if (r.state === "failed") return <Box title="Payment failed"><p>Your payment was not successful and you were not charged for order {o?.order_number}.</p><Link href="/cart" className="btn mx-auto">Try again</Link></Box>;
  if (r.state === "abandoned") return <Box title="Payment not completed"><p>You left the payment page before paying. Your cart is still saved.</p><Link href="/cart" className="btn mx-auto">Back to cart</Link></Box>;
  return <Box title="Confirming your payment"><p>We have not received confirmation yet. Refresh this page in a few seconds. If you were charged, your order will be confirmed automatically.</p><Link href={`/checkout/result?reference=${reference}`} className="btn mx-auto">Refresh</Link></Box>;
}
