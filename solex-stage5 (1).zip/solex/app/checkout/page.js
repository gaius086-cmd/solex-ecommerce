import { serverClient } from "@/lib/supabase-server";
import { isConfigured } from "@/lib/supabase";
import { STATES } from "@/lib/checkout";
import CheckoutForm from "./CheckoutForm";
export const dynamic = "force-dynamic";
export const metadata = { title: "Checkout | SOLEX" };
export default async function Checkout() {
  let user = null, profile = null, addresses = [];
  if (isConfigured) {
    const supabase = serverClient();
    ({ data: { user } } = await supabase.auth.getUser());
    if (user) {
      [{ data: profile }, { data: addresses }] = await Promise.all([supabase.from("profiles").select("full_name,phone").eq("id", user.id).maybeSingle(), supabase.from("addresses").select("*").eq("user_id", user.id).order("is_default", { ascending: false })]);
    }
  }
  return <CheckoutForm email={user?.email || ""} loggedIn={!!user} profile={profile} addresses={addresses || []} states={STATES} />;
}
