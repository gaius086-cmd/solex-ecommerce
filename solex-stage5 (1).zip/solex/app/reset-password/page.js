import { redirect } from "next/navigation";
import AuthShell from "@/components/AuthShell";
import { serverClient } from "@/lib/supabase-server";
import { resetPassword } from "../login/actions";
const E = { short: "Password must be at least 8 characters.", match: "The two passwords do not match.", failed: "Could not update the password. Request a new link." };
export default async function Reset({ searchParams }) {
  const { data: { user } } = await serverClient().auth.getUser();
  if (!user) redirect("/forgot-password?error=expired");
  return (
    <AuthShell title="Choose a new password" error={E[searchParams.error]}>
      <form action={resetPassword} className="grid gap-3">
        <input name="password" type="password" required minLength={8} placeholder="New password" aria-label="New password" autoComplete="new-password" className="field" />
        <input name="confirm" type="password" required minLength={8} placeholder="Confirm new password" aria-label="Confirm password" autoComplete="new-password" className="field" />
        <button className="btn">Update password</button>
      </form>
    </AuthShell>
  );
}
