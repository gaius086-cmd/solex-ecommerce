import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import { register } from "../login/actions";
const E = { name: "Please enter your name.", short: "Password must be at least 8 characters.", match: "The two passwords do not match.", failed: "Could not create the account. Try again or log in." };
export default function Register({ searchParams }) {
  if (searchParams.sent) return <AuthShell title="Check your email" notice="If this email can be registered, we sent a confirmation link. Open it to finish creating your account." />;
  return (
    <AuthShell title="Create account" error={E[searchParams.error]}>
      <form action={register} className="grid gap-3">
        <input name="full_name" required placeholder="Full name" aria-label="Full name" autoComplete="name" className="field" />
        <input name="email" type="email" required placeholder="Email" aria-label="Email" autoComplete="email" className="field" />
        <input name="password" type="password" required minLength={8} placeholder="Password (8+ characters)" aria-label="Password" autoComplete="new-password" className="field" />
        <input name="confirm" type="password" required minLength={8} placeholder="Confirm password" aria-label="Confirm password" autoComplete="new-password" className="field" />
        <button className="btn">Create account</button>
      </form>
      <p className="mt-5 text-sm">Already have an account? <Link href="/login" className="underline">Log in</Link></p>
    </AuthShell>
  );
}
