"use client";
import { useState } from "react";
import { useCart } from "@/components/CartProvider";
import { naira } from "@/lib/supabase";
import WishlistButton from "@/components/WishlistButton";
export default function ProductBuy({ p }) {
  const { add } = useCart();
  const [img, setImg] = useState(0), [size, setSize] = useState(null), [color, setColor] = useState(p.product_colors?.[0]?.name || null), [msg, setMsg] = useState("");
  const price = p.sale_price && p.sale_price < p.price ? p.sale_price : p.price;
  const imgs = p.product_images || [];
  const submit = () => {
    if (!size) return setMsg("Choose a size first.");
    add({ id: p.id, slug: p.slug, name: p.name, image: imgs[0]?.url, price, size, color }); setMsg("Added to cart.");
  };
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 grid md:grid-cols-2 gap-10">
      <div>
        <div className="aspect-square bg-mist">{imgs[img] ? <img src={imgs[img].url} alt={p.name} className="h-full w-full object-cover" /> : <div className="h-full grid place-items-center text-neutral-400 text-sm">No image</div>}</div>
        <div className="mt-3 flex gap-2">{imgs.map((i, n) => <button key={n} onClick={() => setImg(n)} aria-label={`Image ${n + 1}`} className={`h-16 w-16 bg-mist border ${n === img ? "border-ink" : "border-transparent"}`}><img src={i.url} alt="" className="h-full w-full object-cover" /></button>)}</div>
      </div>
      <div>
        <p className="text-sm text-neutral-500">{p.brands?.name} · {p.categories?.name}</p>
        <h1 className="font-display text-4xl mt-1">{p.name}</h1>
        <p className="mt-4 text-xl font-semibold">{naira(price)} {price < p.price && <s className="text-neutral-400 text-base font-normal">{naira(p.price)}</s>}</p>
        {!!p.product_colors?.length && <div className="mt-8"><p className="text-sm font-semibold mb-2">Colour: {color}</p><div className="flex gap-2">{p.product_colors.map((c) => <button key={c.name} onClick={() => setColor(c.name)} aria-label={c.name} className={`h-9 w-9 rounded-full border-2 ${color === c.name ? "border-ink" : "border-line"}`} style={{ background: c.hex || "#ddd" }} />)}</div></div>}
        <div className="mt-8"><p className="text-sm font-semibold mb-2">Size (EU)</p>
          <div className="grid grid-cols-5 gap-2">{(p.product_sizes || []).sort((a, b) => a.size - b.size).map((s) => <button key={s.size} disabled={s.stock < 1} onClick={() => setSize(s.size)} className={`border py-2 text-sm ${size === s.size ? "bg-ink text-paper" : "border-line"} disabled:text-neutral-300 disabled:line-through`}>{s.size}</button>)}</div>
        </div>
        <div className="mt-8 flex gap-2"><button onClick={submit} className="btn flex-1">Add to cart</button><WishlistButton id={p.id} className="!h-auto w-12" /></div>
        {msg && <p role="status" className="mt-3 text-sm">{msg}</p>}
        <p className="mt-8 text-sm leading-relaxed text-neutral-700 max-w-prose whitespace-pre-line">{p.description}</p>
      </div>
    </div>
  );
}
