import { notFound } from "next/navigation";
import { supabase, isConfigured } from "@/lib/supabase";
import ProductBuy from "./ProductBuy";
export const dynamic = "force-dynamic";
export default async function Product({ params }) {
  if (!isConfigured) return <p className="p-10">Supabase is not configured.</p>;
  const { data: p } = await supabase.from("products")
    .select("*,brands(name),categories(name),product_images(url,position),product_sizes(size,stock),product_colors(name,hex)")
    .eq("slug", params.slug).eq("is_active", true).maybeSingle();
  if (!p) notFound();
  p.product_images?.sort((a, b) => a.position - b.position);
  return <ProductBuy p={p} />;
}
