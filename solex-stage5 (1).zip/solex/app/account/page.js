import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { naira } from "@/lib/supabase";
export default async function Account({ searchParams }) {
  const { supabase, user } = await requireUser();
  const [{ data: p }, addr, { data: orders }] = await Promise.all([
    supabase.from("profiles").select("full_name,phone").eq("id", user.id).maybeSingle(),
    supabase.from("addresses").select("id", { count: "exact", head: true }).eq("user_id", user.id),
    supabase.from("orders").select("id,order_number,status,total,created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(3),
  ]);
  return (
    <>
      {searchParams.pw && <p role="status" className="border border-ink text-sm p-3 mb-6">Your password was updated.</p>}
      <h1 className="font-display text-3xl">Hello{p?.full_name ? `, ${p.full_name.split(" ")[0]}` : ""}</h1>
      <p className="text-sm text-neutral-500 mt-1">{user.email}</p>
      <div className="grid sm:grid-cols-3 gap-px bg-line border border-line mt-8">
        <Link href="/account/profile" className="bg-paper p-5 hover:bg-mist"><p className="text-xs text-neutral-500">Profile</p><p className="font-semibold mt-1">{p?.phone ? "Complete" : "Add your phone number"}</p></Link>
        <Link href="/account/addresses" className="bg-paper p-5 hover:bg-mist"><p className="text-xs text-neutral-500">Saved addresses</p><p className="font-semibold mt-1">{addr.count ?? 0}</p></Link>
        <Link href="/account/orders" className="bg-paper p-5 hover:bg-mist"><p className="text-xs text-neutral-500">Orders</p><p className="font-semibold mt-1">{orders?.length ? "View all" : "None yet"}</p></Link>
      </div>
      <h2 className="font-semibold mt-10 mb-3">Recent orders</h2>
      {orders?.length ? <ul className="divide-y divide-line border border-line text-sm">{orders.map((o) => <li key={o.id} className="p-3 flex justify-between"><span>{o.order_number || o.id.slice(0, 8)} · {o.status}</span><span>{naira(o.total)}</span></li>)}</ul> : <p className="text-sm text-neutral-500 border border-line p-5">No orders yet. <Link href="/shop" className="underline">Browse shoes</Link></p>}
    </>
  );
}
