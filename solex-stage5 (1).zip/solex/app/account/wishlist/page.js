import Link from "next/link";
import { requireUser } from "@/lib/auth";
import ProductGrid from "@/components/ProductGrid";
export default async function Wishlist() {
  const { supabase, user } = await requireUser();
  const { data } = await supabase.from("wishlists").select("created_at,products(id,slug,name,price,sale_price,is_active,brands(name),product_images(url,position))").eq("user_id", user.id).order("created_at", { ascending: false });
  const products = (data || []).map((r) => r.products).filter((p) => p && p.is_active);
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Wishlist</h1>
      <ProductGrid products={products} empty="Your wishlist is empty. Tap the heart on any shoe to save it here." />
      {!products.length && <Link href="/shop" className="btn mt-6">Browse shoes</Link>}
    </>
  );
}
