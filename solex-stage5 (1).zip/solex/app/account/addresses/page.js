import { requireUser } from "@/lib/auth";
import { saveAddress, deleteAddress, makeDefault } from "../actions";
const E = { required: "Name, address line 1, city and state are required.", phone: "Enter a valid phone number.", failed: "Could not save the address." };
export default async function Addresses({ searchParams }) {
  const { supabase, user } = await requireUser();
  const { data } = await supabase.from("addresses").select("*").eq("user_id", user.id).order("is_default", { ascending: false }).order("created_at");
  const edit = data?.find((a) => a.id === searchParams.edit);
  const L = ({ t, n, req, v, type }) => <label className="grid gap-1 text-xs font-semibold">{t}<input name={n} required={req} type={type || "text"} defaultValue={v || ""} className="field" /></label>;
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Delivery addresses</h1>
      {searchParams.error && <p role="alert" className="border border-sale text-sale text-sm p-3 mb-4">{E[searchParams.error]}</p>}
      {searchParams.saved && <p role="status" className="border border-ink text-sm p-3 mb-4">Address saved.</p>}
      {!data?.length ? <p className="text-sm text-neutral-500 border border-line p-5 mb-8">No saved addresses yet. Add one below.</p> : (
        <ul className="grid sm:grid-cols-2 gap-4 mb-10">{data.map((a) => (
          <li key={a.id} className="border border-line p-4 text-sm">
            <p className="font-semibold">{a.label || "Address"} {a.is_default && <span className="text-xs border border-ink px-1.5 ml-1">Default</span>}</p>
            <p className="mt-2">{a.full_name} · {a.phone}</p><p>{a.line1}{a.line2 ? `, ${a.line2}` : ""}</p><p>{a.city}, {a.state}{a.postal_code ? ` ${a.postal_code}` : ""}</p><p>{a.country}</p>
            <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs">
              <a href={`/account/addresses?edit=${a.id}`} className="underline">Edit</a>
              {!a.is_default && <form action={makeDefault}><input type="hidden" name="id" value={a.id} /><button className="underline">Make default</button></form>}
              <form action={deleteAddress}><input type="hidden" name="id" value={a.id} /><button className="underline text-sale">Delete</button></form>
            </div>
          </li>))}</ul>
      )}
      <h2 className="font-semibold mb-3">{edit ? "Edit address" : "Add an address"}</h2>
      <form action={saveAddress} key={edit?.id || "new"} className="grid sm:grid-cols-2 gap-3 max-w-2xl">
        <input type="hidden" name="id" value={edit?.id || ""} />
        <L t="Label (Home, Office)" n="label" v={edit?.label} /><L t="Full name" n="full_name" req v={edit?.full_name} />
        <L t="Phone" n="phone" type="tel" req v={edit?.phone} /><L t="Address line 1" n="line1" req v={edit?.line1} />
        <L t="Address line 2" n="line2" v={edit?.line2} /><L t="City" n="city" req v={edit?.city} />
        <L t="State" n="state" req v={edit?.state} /><L t="Postal code" n="postal_code" v={edit?.postal_code} />
        <L t="Country" n="country" req v={edit?.country || "Nigeria"} />
        <label className="flex gap-2 text-sm items-center"><input type="checkbox" name="is_default" defaultChecked={edit?.is_default} /> Make default</label>
        <div className="sm:col-span-2 flex gap-3"><button className="btn">{edit ? "Save changes" : "Add address"}</button>{edit && <a href="/account/addresses" className="btn-out">Cancel</a>}</div>
      </form>
    </>
  );
}
