import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { naira } from "@/lib/supabase";
import OrderTimeline from "@/components/OrderTimeline";
export default async function MyOrders() {
  const { supabase, user } = await requireUser();
  const { data } = await supabase.from("orders").select("id,order_number,status,subtotal,shipping_fee,discount_code,discount_amount,total,created_at,courier,tracking_number,order_items(name,size,color,qty,unit_price),order_events(status,created_at)").eq("user_id", user.id).order("created_at", { ascending: false });
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Orders</h1>
      {!data?.length ? <p className="text-sm text-neutral-500 border border-line p-5">No orders yet. <Link href="/shop" className="underline">Browse shoes</Link></p> : (
        <ul className="grid gap-4">{data.map((o) => (
          <li key={o.id} className="border border-line p-4 text-sm grid gap-3">
            <div className="flex justify-between gap-2"><p className="font-semibold">{o.order_number || o.id.slice(0, 8)} · {o.status}</p><p>{naira(o.total)}</p></div>
            <p className="text-neutral-500">Placed {new Date(o.created_at).toLocaleDateString("en-NG")}</p>
            <ul>{o.order_items?.map((i, n) => <li key={n}>{i.qty} × {i.name} (size {i.size}{i.color ? `, ${i.color}` : ""}) · {naira(i.unit_price * i.qty)}</li>)}</ul>
            <p className="text-neutral-500">Subtotal {naira(o.subtotal)}{o.discount_amount > 0 ? ` · Discount ${o.discount_code} −${naira(o.discount_amount)}` : ""} · Delivery {naira(o.shipping_fee)}</p>
            <OrderTimeline order={o} />
          </li>))}</ul>)}
    </>
  );
}
