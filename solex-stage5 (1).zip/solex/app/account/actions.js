"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { adminClient } from "@/lib/supabase-admin";
const s = (fd, k) => String(fd.get(k) || "").trim();
export async function saveProfile(fd) {
  const { supabase, user } = await requireUser();
  const phone = s(fd, "phone");
  if (!s(fd, "full_name")) redirect("/account/profile?error=name");
  if (phone && !/^[+0-9 ()-]{7,20}$/.test(phone)) redirect("/account/profile?error=phone");
  const { error } = await supabase.from("profiles").update({ full_name: s(fd, "full_name"), phone: phone || null }).eq("id", user.id);
  if (error) redirect("/account/profile?error=failed");
  revalidatePath("/account"); redirect("/account/profile?saved=1");
}
export async function changePassword(fd) {
  const { supabase } = await requireUser();
  const pw = String(fd.get("password") || "");
  if (pw.length < 8) redirect("/account/profile?error=short");
  if (pw !== String(fd.get("confirm") || "")) redirect("/account/profile?error=match");
  const { error } = await supabase.auth.updateUser({ password: pw });
  redirect(`/account/profile?${error ? "error=failed" : "pw=1"}`);
}
export async function saveAddress(fd) {
  const { supabase, user } = await requireUser();
  const id = s(fd, "id") || null;
  const row = { label: s(fd, "label") || null, full_name: s(fd, "full_name"), phone: s(fd, "phone"), line1: s(fd, "line1"), line2: s(fd, "line2") || null, city: s(fd, "city"), state: s(fd, "state"), postal_code: s(fd, "postal_code") || null, country: s(fd, "country") || "Nigeria" };
  const back = (e) => redirect(`/account/addresses?error=${e}${id ? `&edit=${id}` : ""}`);
  if (!row.full_name || !row.line1 || !row.city || !row.state) back("required");
  if (!/^[+0-9 ()-]{7,20}$/.test(row.phone)) back("phone");
  const wantDefault = fd.get("is_default") === "on";
  const { count } = await supabase.from("addresses").select("id", { count: "exact", head: true }).eq("user_id", user.id);
  const makeDefault = wantDefault || (!id && !count);
  if (makeDefault) await supabase.from("addresses").update({ is_default: false }).eq("user_id", user.id);
  const { error } = id
    ? await supabase.from("addresses").update({ ...row, ...(makeDefault ? { is_default: true } : {}) }).eq("id", id).eq("user_id", user.id)
    : await supabase.from("addresses").insert({ ...row, user_id: user.id, is_default: makeDefault });
  if (error) back("failed");
  revalidatePath("/account/addresses"); redirect("/account/addresses?saved=1");
}
export async function deleteAddress(fd) {
  const { supabase, user } = await requireUser();
  await supabase.from("addresses").delete().eq("id", s(fd, "id")).eq("user_id", user.id);
  revalidatePath("/account/addresses"); redirect("/account/addresses");
}
export async function makeDefault(fd) {
  const { supabase, user } = await requireUser();
  await supabase.from("addresses").update({ is_default: false }).eq("user_id", user.id);
  await supabase.from("addresses").update({ is_default: true }).eq("id", s(fd, "id")).eq("user_id", user.id);
  revalidatePath("/account/addresses"); redirect("/account/addresses");
}

// Permanent deletion. Safeguards: typed confirmation, password re-entry, admins excluded, blocked while orders are in progress.
export async function deleteAccount(fd) {
  const { supabase, user } = await requireUser();
  const back = (e) => redirect(`/account/profile?error=${e}`);
  if (String(fd.get("confirm") || "").trim() !== "DELETE") back("confirm");
  const db = adminClient(); if (!db) back("config");
  const { data: p } = await db.from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (p?.role === "admin") back("admin");
  const { error: authErr } = await supabase.auth.signInWithPassword({ email: user.email, password: String(fd.get("password") || "") });
  if (authErr) back("password");
  const recent = new Date(Date.now() - 2 * 3600 * 1000).toISOString();
  const { count } = await db.from("orders").select("id", { count: "exact", head: true }).eq("user_id", user.id).or(`status.in.(paid,processing,shipped),and(status.eq.pending,created_at.gte.${recent})`);
  if (count) back("open");
  const { data: orders } = await db.from("orders").select("id").eq("user_id", user.id);
  const ids = (orders || []).map((o) => o.id);
  await db.from("contact_messages").delete().eq("email", String(user.email).toLowerCase());
  const { error } = await db.auth.admin.deleteUser(user.id); // cascades to profile, addresses, wishlist and saved cart
  if (error) back("delete");
  if (ids.length) { // keep order records for bookkeeping, remove personal details
    await db.from("orders").update({ status: "cancelled" }).in("id", ids).eq("status", "pending");
    await db.from("orders").update({ customer_name: "Deleted customer", email: null, phone: null, shipping_address: null }).in("id", ids);
  }
  await supabase.auth.signOut();
  redirect("/");
}
