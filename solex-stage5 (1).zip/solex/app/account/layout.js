import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { logout } from "../login/actions";
export const dynamic = "force-dynamic";
export default async function AccountLayout({ children }) {
  await requireUser();
  const tabs = [["Overview", "/account"], ["Profile", "/account/profile"], ["Addresses", "/account/addresses"], ["Wishlist", "/account/wishlist"], ["Orders", "/account/orders"]];
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <nav aria-label="Account" className="flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-line pb-4 mb-8 text-sm">
        {tabs.map(([l, h]) => <Link key={h} href={h} className="font-semibold hover:underline underline-offset-4">{l}</Link>)}
        <form action={logout} className="ml-auto"><button className="underline">Log out</button></form>
      </nav>
      {children}
    </div>
  );
}
