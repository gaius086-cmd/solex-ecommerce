import { requireUser } from "@/lib/auth";
import { saveProfile, changePassword, deleteAccount } from "../actions";
const E = { name: "Name is required.", phone: "Enter a valid phone number.", failed: "Could not save. Try again.", short: "Password must be at least 8 characters.", match: "The two passwords do not match.", confirm: "Type DELETE to confirm.", password: "Password is incorrect.", open: "You have an order in progress. You can delete your account after it is delivered or cancelled.", admin: "Admin accounts cannot be deleted here.", config: "Account deletion is not configured.", delete: "Could not delete the account. Try again." };
export default async function Profile({ searchParams }) {
  const { supabase, user } = await requireUser();
  const { data: p } = await supabase.from("profiles").select("full_name,phone").eq("id", user.id).maybeSingle();
  return (
    <>
      <h1 className="font-display text-3xl mb-6">Profile</h1>
      {searchParams.error && <p role="alert" className="border border-sale text-sale text-sm p-3 mb-4">{E[searchParams.error]}</p>}
      {(searchParams.saved || searchParams.pw) && <p role="status" className="border border-ink text-sm p-3 mb-4">{searchParams.pw ? "Password updated." : "Profile saved."}</p>}
      <form action={saveProfile} className="grid gap-3 max-w-md">
        <label className="grid gap-1 text-xs font-semibold">Email<input value={user.email} disabled className="field text-neutral-500" /></label>
        <label className="grid gap-1 text-xs font-semibold">Full name<input name="full_name" required defaultValue={p?.full_name || ""} autoComplete="name" className="field" /></label>
        <label className="grid gap-1 text-xs font-semibold">Phone<input name="phone" type="tel" defaultValue={p?.phone || ""} autoComplete="tel" className="field" /></label>
        <button className="btn">Save profile</button>
      </form>
      <h2 className="font-semibold mt-12 mb-3">Change password</h2>
      <form action={changePassword} className="grid gap-3 max-w-md">
        <input name="password" type="password" required minLength={8} placeholder="New password" aria-label="New password" autoComplete="new-password" className="field" />
        <input name="confirm" type="password" required minLength={8} placeholder="Confirm new password" aria-label="Confirm password" autoComplete="new-password" className="field" />
        <button className="btn-out">Update password</button>
      </form>
      <h2 className="font-semibold mt-12 mb-1 text-sale">Delete account</h2>
      <p className="text-sm text-neutral-600 mb-3 max-w-md">This permanently removes your profile, addresses, wishlist and saved cart. Past orders are kept for our records without your name, contact details or address. This cannot be undone.</p>
      <form action={deleteAccount} className="grid gap-3 max-w-md">
        <input name="password" type="password" required placeholder="Your password" aria-label="Password" autoComplete="current-password" className="field" />
        <input name="confirm" required placeholder="Type DELETE to confirm" aria-label="Type DELETE" autoComplete="off" className="field" />
        <button className="btn-out !border-sale !text-sale">Delete my account</button>
      </form>
    </>
  );
}
