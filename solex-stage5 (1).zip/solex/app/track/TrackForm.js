"use client";
import { useFormState } from "react-dom";
import { trackOrder } from "./actions";
import OrderTimeline from "@/components/OrderTimeline";
import { naira } from "@/lib/supabase";
export default function TrackForm() {
  const [s, action] = useFormState(trackOrder, null);
  const o = s?.order;
  return (
    <div className="mx-auto max-w-lg px-4 py-14">
      <h1 className="font-display text-3xl mb-2">Track your order</h1>
      <p className="text-sm text-neutral-500 mb-6">Enter your order number and the email you used at checkout.</p>
      <form action={action} className="grid gap-3">
        <input name="order_number" required placeholder="Order number (e.g. SOL-1001)" aria-label="Order number" className="field" />
        <input name="email" type="email" required placeholder="Email" aria-label="Email" autoComplete="email" className="field" />
        <button className="btn">Track order</button>
      </form>
      {s?.error && <p role="alert" className="border border-sale text-sale text-sm p-3 mt-4">{s.error}</p>}
      {o && (
        <div className="mt-8 border border-line p-4 text-sm grid gap-4">
          <p className="font-semibold">{o.order_number} · {o.status}</p>
          <OrderTimeline order={o} />
          <ul>{o.order_items.map((i, n) => <li key={n}>{i.qty} × {i.name} (size {i.size}{i.color ? `, ${i.color}` : ""})</li>)}</ul>
          <p className="text-neutral-600">Subtotal {naira(o.subtotal)}{o.discount_amount > 0 ? ` · Discount −${naira(o.discount_amount)}` : ""} · Delivery {naira(o.shipping_fee)} · <b>Total {naira(o.total)}</b></p>
        </div>)}
    </div>
  );
}
