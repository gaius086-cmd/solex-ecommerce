import TrackForm from "./TrackForm"; export const metadata = { title: "Track an order | SOLEX" }; export default function Track() { return <TrackForm />; }
