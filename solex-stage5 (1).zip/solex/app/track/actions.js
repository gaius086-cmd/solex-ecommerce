"use server";
import { adminClient } from "@/lib/supabase-admin";
import { limited, ipKey } from "@/lib/ratelimit";
// Verification = order number + the email used at checkout. Both must match. Failures look identical.
export async function trackOrder(_prev, fd) {
  const number = String(fd.get("order_number") || "").trim().toUpperCase(), email = String(fd.get("email") || "").trim().toLowerCase();
  if (!number || !email) return { error: "Enter your order number and the email used at checkout." };
  const db = adminClient();
  if (!db) return { error: "Order tracking is not configured yet." };
  if (await limited(db, "track:" + ipKey(), 10, 15)) return { error: "Too many attempts. Please try again in a few minutes." };
  const { data: o } = await db.from("orders").select("order_number,status,subtotal,shipping_fee,discount_amount,total,created_at,courier,tracking_number,order_items(name,size,color,qty),order_events(status,created_at)").eq("order_number", number).eq("email", email).maybeSingle();
  if (!o) return { error: "We couldn't find an order with those details." };
  return { order: o }; // no address, phone or email is returned
}
