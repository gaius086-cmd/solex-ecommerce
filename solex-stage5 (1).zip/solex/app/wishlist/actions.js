"use server";
import { serverClient } from "@/lib/supabase-server";
import { isConfigured } from "@/lib/supabase";
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
// null = guest (not signed in)
export async function getWishlistIds() {
  if (!isConfigured) return null;
  const supabase = serverClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.from("wishlists").select("product_id").eq("user_id", user.id);
  return (data || []).map((r) => r.product_id);
}
export async function toggleWishlist(productId, wish) {
  if (!UUID.test(String(productId))) return { ok: false };
  const supabase = serverClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { ok: false, login: true };
  const { error } = wish
    ? await supabase.from("wishlists").upsert({ user_id: user.id, product_id: productId }, { onConflict: "user_id,product_id", ignoreDuplicates: true })
    : await supabase.from("wishlists").delete().eq("user_id", user.id).eq("product_id", productId);
  return { ok: !error };
}
