"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useCart } from "@/components/CartProvider";
import { priceCart } from "./actions";
import { naira } from "@/lib/supabase";
export default function Cart() {
  const { items, setQty, remove, clear, ready, loggedIn } = useCart();
  const [q, setQ] = useState(null);
  useEffect(() => {
    if (!ready || !items.length) { setQ(null); return; }
    priceCart(items.map(({ id, size, color, qty }) => ({ id, size, color, qty }))).then(setQ).catch(() => setQ({ lines: [], issues: ["Could not load prices. Refresh the page."], subtotal: 0 }));
  }, [ready, items]);
  if (!ready) return <p className="p-10 text-sm">Loading your cart…</p>;
  if (!items.length) return <div className="mx-auto max-w-3xl px-4 py-20 text-center"><h1 className="font-display text-3xl">Your cart is empty</h1><Link href="/shop" className="btn mt-6">Browse shoes</Link></div>;
  const blocked = !q || q.issues.length > 0 || !q.lines.length;
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="font-display text-3xl mb-2">Cart</h1>
      <p className="text-xs text-neutral-500 mb-6">{loggedIn ? "Saved to your account." : <>Log in to save your cart across devices. <Link href="/login?next=/cart" className="underline">Log in</Link></>}</p>
      {q?.issues.length > 0 && <ul role="alert" className="border border-sale text-sale text-sm p-3 mb-4 grid gap-1">{q.issues.map((m) => <li key={m}>{m}</li>)}</ul>}
      {!q ? <p className="text-sm">Checking prices and stock…</p> : (
        <ul className="divide-y divide-line border-y border-line">
          {q.lines.map((l) => (
            <li key={`${l.id}${l.size}${l.color}`} className="py-4 flex gap-3 sm:gap-4 items-center">
              <div className="h-20 w-20 bg-mist shrink-0">{l.image && <img src={l.image} alt="" className="h-full w-full object-cover" />}</div>
              <div className="flex-1 text-sm min-w-0"><Link href={`/product/${l.slug}`} className="font-semibold">{l.name}</Link><p className="text-neutral-500">Size {l.size}{l.color ? ` · ${l.color}` : ""} · {naira(l.unit)}</p><button onClick={() => remove(l)} className="underline text-xs mt-1">Remove</button></div>
              <div className="flex items-center gap-2 text-sm"><button onClick={() => setQty(l, l.qty - 1)} aria-label="Decrease" className="border border-line w-8 h-8">−</button>{l.qty}<button onClick={() => setQty(l, l.qty + 1)} aria-label="Increase" className="border border-line w-8 h-8">+</button></div>
              <p className="w-20 sm:w-24 text-right text-sm font-semibold">{naira(l.total)}</p>
            </li>))}
        </ul>)}
      <div className="mt-6 flex flex-wrap justify-between items-center gap-4"><button onClick={clear} className="underline text-sm">Clear cart</button>
        <div className="flex items-center gap-4"><p className="font-semibold">Subtotal {naira(q?.subtotal || 0)}</p>{blocked ? <button disabled className="btn">Checkout</button> : <Link href="/checkout" className="btn">Checkout</Link>}</div></div>
      <p className="text-xs text-neutral-500 mt-3">Delivery is calculated at checkout.</p>
    </div>
  );
}
