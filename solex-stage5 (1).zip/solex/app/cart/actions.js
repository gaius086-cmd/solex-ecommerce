"use server";
import { serverClient } from "@/lib/supabase-server";
import { validateCart } from "@/lib/checkout";
import { isConfigured } from "@/lib/supabase";
export async function priceCart(items) { return validateCart(serverClient(), items); }
// Returns the signed-in customer's saved cart, or null for guests.
export async function loadServerCart() {
  if (!isConfigured) return null;
  const supabase = serverClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.from("cart_items").select("product_id,size,color,qty").eq("user_id", user.id);
  return (data || []).map((r) => ({ id: r.product_id, size: Number(r.size), color: r.color || null, qty: r.qty }));
}
export async function saveServerCart(items) {
  const supabase = serverClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !Array.isArray(items)) return;
  const rows = items.slice(0, 50).map((i) => ({ user_id: user.id, product_id: String(i.id), size: Number(i.size), color: i.color ? String(i.color) : "", qty: Math.min(10, Math.max(1, Math.floor(Number(i.qty)))) })).filter((r) => Number.isFinite(r.size));
  await supabase.from("cart_items").delete().eq("user_id", user.id);
  if (rows.length) await supabase.from("cart_items").insert(rows);
}
