"use client";
import Link from "next/link";
import { useState } from "react";
import { useCart } from "./CartProvider";
import AccountLink from "./AccountLink";
const nav = [["Home","/"],["Shop","/shop"],["Men","/shop?gender=men"],["Women","/shop?gender=women"],["Kids","/shop?gender=kids"],["Brands","/shop#brands"],["Sale","/shop?flag=sale"]];
export default function Header() {
  const { count } = useCart(); const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-30 bg-paper border-b border-line">
      <div className="mx-auto max-w-7xl px-4 h-16 flex items-center justify-between gap-6">
        <Link href="/" className="font-display text-2xl tracking-tight">SOLEX</Link>
        <nav className="hidden md:flex gap-7 text-sm font-medium" aria-label="Main">
          {nav.map(([l, h]) => <Link key={l} href={h} className={l === "Sale" ? "text-sale" : "hover:underline underline-offset-4"}>{l}</Link>)}
        </nav>
        <div className="flex items-center gap-5 text-sm font-medium">
          <form action="/shop" className="hidden sm:block"><input name="q" placeholder="Search shoes" aria-label="Search shoes" className="border border-line px-3 py-1.5 w-44 text-sm" /></form>
          <AccountLink />
          <Link href="/account">Account</Link>
          <Link href="/cart">Cart ({count})</Link>
          <button className="md:hidden" onClick={() => setOpen(!open)} aria-expanded={open}>Menu</button>
        </div>
      </div>
      {open && <nav className="md:hidden border-t border-line px-4 py-3 grid gap-3 text-sm" aria-label="Mobile">{nav.map(([l, h]) => <Link key={l} href={h} onClick={() => setOpen(false)}>{l}</Link>)}<Link href="/account" onClick={() => setOpen(false)}>Account</Link></nav>}
    </header>
  );
}
