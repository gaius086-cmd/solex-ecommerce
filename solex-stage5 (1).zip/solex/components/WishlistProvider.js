"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { getWishlistIds, toggleWishlist } from "@/app/wishlist/actions";
const Ctx = createContext({ has: () => false, toggle: () => {} });
export const useWishlist = () => useContext(Ctx);
export default function WishlistProvider({ children }) {
  const [ids, setIds] = useState(new Set()); const [loggedIn, setLoggedIn] = useState(false);
  useEffect(() => { getWishlistIds().then((r) => { if (r) { setIds(new Set(r)); setLoggedIn(true); } }).catch(() => {}); }, []);
  const flip = (id, on) => setIds((p) => { const n = new Set(p); on ? n.add(id) : n.delete(id); return n; });
  const toggle = async (id) => {
    if (!loggedIn) { window.location.href = "/login?next=" + encodeURIComponent(window.location.pathname + window.location.search); return; }
    const want = !ids.has(id); flip(id, want);
    const r = await toggleWishlist(id, want).catch(() => null);
    if (!r?.ok) flip(id, !want); // roll back if the server refused
  };
  return <Ctx.Provider value={{ has: (id) => ids.has(id), toggle }}>{children}</Ctx.Provider>;
}
