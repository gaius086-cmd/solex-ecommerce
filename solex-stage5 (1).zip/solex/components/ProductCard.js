import Link from "next/link";
import { naira } from "@/lib/supabase";
import WishlistButton from "./WishlistButton";
export default function ProductCard({ p }) {
  const img = [...(p.product_images || [])].sort((a, b) => a.position - b.position)[0]?.url;
  const onSale = p.sale_price && p.sale_price < p.price;
  return (
    <div className="group relative">
      <Link href={`/product/${p.slug}`} className="block">
        <div className="relative aspect-square bg-mist overflow-hidden">
          {img ? <img src={img} alt={p.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" loading="lazy" /> : <div className="h-full grid place-items-center text-sm text-neutral-400">No image</div>}
          {onSale && <span className="absolute left-3 top-3 bg-sale text-paper text-xs font-semibold px-2 py-1">Sale</span>}
        </div>
        <p className="mt-3 text-xs text-neutral-500">{p.brands?.name}</p>
        <h3 className="text-sm font-semibold leading-snug">{p.name}</h3>
        <p className="mt-1 text-sm">{onSale ? <><span className="font-semibold text-sale">{naira(p.sale_price)}</span> <s className="text-neutral-400">{naira(p.price)}</s></> : <span className="font-semibold">{naira(p.price)}</span>}</p>
      </Link>
      <WishlistButton id={p.id} className="absolute right-2 top-2" />
    </div>
  );
}
