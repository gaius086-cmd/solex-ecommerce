"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { browserClient } from "@/lib/supabase-browser";
// Label only. Real protection happens in middleware, server code and Row Level Security.
export default function AccountLink() {
  const [signedIn, setSignedIn] = useState(null); const path = usePathname();
  useEffect(() => { const sb = browserClient(); if (!sb) return setSignedIn(false); sb.auth.getSession().then(({ data }) => setSignedIn(!!data.session)); }, [path]);
  if (signedIn === null) return <span className="w-14" aria-hidden />;
  return signedIn ? <Link href="/account">Account</Link> : <Link href="/login">Log in</Link>;
}
