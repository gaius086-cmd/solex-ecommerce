import ProductCard from "./ProductCard";
export default function ProductGrid({ products, error, empty = "No shoes match yet. Try different filters." }) {
  if (error) return <p role="alert" className="border border-line p-6 text-sm">{error}</p>;
  if (!products.length) return <p className="border border-line p-6 text-sm text-neutral-600">{empty}</p>;
  return <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-10">{products.map((p) => <ProductCard key={p.id} p={p} />)}</div>;
}
