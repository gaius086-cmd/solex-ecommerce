const LABEL = { pending: "Order placed", paid: "Payment confirmed", processing: "Being prepared", shipped: "Shipped", delivered: "Delivered", cancelled: "Cancelled" };
export default function OrderTimeline({ order }) {
  const ev = [...(order.order_events || [])].sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  return (
    <div className="text-sm">
      {(order.courier || order.tracking_number) && <p className="mb-2">Courier: <b>{order.courier || "n/a"}</b> · Tracking no: <b>{order.tracking_number || "n/a"}</b></p>}
      <ol className="border-l border-line pl-4 grid gap-2">{ev.map((e, i) => <li key={i} className="relative"><span className="absolute -left-[21px] top-1.5 h-2 w-2 bg-ink rounded-full" /><b>{LABEL[e.status] || e.status}</b> <span className="text-neutral-500">{new Date(e.created_at).toLocaleString("en-NG")}</span></li>)}</ol>
    </div>
  );
}
