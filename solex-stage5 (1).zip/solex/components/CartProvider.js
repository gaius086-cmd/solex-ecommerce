"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { loadServerCart, saveServerCart } from "@/app/cart/actions";
const Ctx = createContext(null);
export const useCart = () => useContext(Ctx);
const key = (i) => `${i.id}|${i.size}|${i.color}`;
export default function CartProvider({ children }) {
  const [items, setItems] = useState([]);
  const [ready, setReady] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  useEffect(() => {
    (async () => {
      let local = []; try { local = JSON.parse(localStorage.getItem("solex-cart") || "[]"); } catch {}
      let server = null; try { server = await loadServerCart(); } catch {}
      if (server) { // signed in: merge the guest cart into the saved cart
        const m = new Map(server.map((i) => [key(i), i]));
        local.forEach((i) => { const p = m.get(key(i)); m.set(key(i), p ? { ...p, qty: Math.min(10, p.qty + i.qty) } : i); });
        setItems([...m.values()]); setLoggedIn(true); try { localStorage.removeItem("solex-cart"); } catch {}
      } else setItems(local);
      setReady(true);
    })();
  }, []);
  useEffect(() => {
    if (!ready) return;
    if (!loggedIn) { try { localStorage.setItem("solex-cart", JSON.stringify(items)); } catch {} return; }
    const t = setTimeout(() => saveServerCart(items.map(({ id, size, color, qty }) => ({ id, size, color, qty }))).catch(() => {}), 400);
    return () => clearTimeout(t);
  }, [items, ready, loggedIn]);
  const add = (item) => setItems((p) => { const f = p.find((x) => key(x) === key(item)); return f ? p.map((x) => key(x) === key(item) ? { ...x, qty: Math.min(10, x.qty + 1) } : x) : [...p, { ...item, qty: 1 }]; });
  const setQty = (item, qty) => setItems((p) => p.map((x) => key(x) === key(item) ? { ...x, qty: Math.min(10, qty) } : x).filter((x) => x.qty > 0));
  const remove = (item) => setItems((p) => p.filter((x) => key(x) !== key(item)));
  const clear = () => setItems([]);
  const count = items.reduce((a, b) => a + b.qty, 0);
  return <Ctx.Provider value={{ items, add, setQty, remove, clear, count, ready, loggedIn }}>{children}</Ctx.Provider>;
}
