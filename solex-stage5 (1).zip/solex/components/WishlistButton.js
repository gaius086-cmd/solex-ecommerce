"use client";
import { useWishlist } from "./WishlistProvider";
export default function WishlistButton({ id, className = "" }) {
  const { has, toggle } = useWishlist(); const on = has(id);
  return (
    <button type="button" onClick={(e) => { e.preventDefault(); toggle(id); }} aria-pressed={on} aria-label={on ? "Remove from wishlist" : "Add to wishlist"} className={`h-10 w-10 grid place-items-center bg-paper border border-line ${className}`}>
      <svg width="18" height="18" viewBox="0 0 24 24" fill={on ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M12 21s-7-4.5-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 6c-2.5 4.5-9.5 9-9.5 9z" /></svg>
    </button>
  );
}
