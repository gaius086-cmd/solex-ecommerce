import Link from "next/link";
export default function Footer() {
  return (
    <footer className="bg-ink text-paper mt-24">
      <div className="mx-auto max-w-7xl px-4 py-14 grid gap-10 sm:grid-cols-4 text-sm">
        <div><p className="font-display text-2xl">SOLEX</p><p className="mt-3 text-neutral-400 max-w-xs">Footwear only. Sneakers, running, boots and formal shoes from the brands you know.</p></div>
        <div className="grid gap-2"><p className="font-semibold">Shop</p><Link href="/shop">All shoes</Link><Link href="/shop?flag=is_new">New arrivals</Link><Link href="/shop?flag=sale">Sale</Link></div>
        <div className="grid gap-2"><p className="font-semibold">Help</p><Link href="/contact">Contact us</Link><Link href="/track">Track an order</Link></div>
        <div className="grid gap-2"><p className="font-semibold">Account</p><Link href="/login">Log in</Link><Link href="/register">Create account</Link></div>
      </div>
      <p className="border-t border-neutral-800 text-center text-xs text-neutral-500 py-5">© {new Date().getFullYear()} SOLEX</p>
    </footer>
  );
}
