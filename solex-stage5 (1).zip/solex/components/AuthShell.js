export default function AuthShell({ title, error, notice, children }) {
  return (
    <div className="mx-auto max-w-sm px-4 py-14 sm:py-20">
      <h1 className="font-display text-3xl mb-6">{title}</h1>
      {error && <p role="alert" className="border border-sale text-sale text-sm p-3 mb-4">{error}</p>}
      {notice && <p role="status" className="border border-ink text-sm p-3 mb-4">{notice}</p>}
      {children}
    </div>
  );
}
