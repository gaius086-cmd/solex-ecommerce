import { createServerClient } from "@supabase/ssr";
import { NextResponse } from "next/server";
export async function middleware(request) {
  const path = request.nextUrl.pathname;
  const isAdminLogin = path === "/admin/login";
  const toLogin = (p, q = "") => NextResponse.redirect(new URL(p + q, request.url));
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL, key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return isAdminLogin ? NextResponse.next() : toLogin(path.startsWith("/admin") ? "/admin/login" : "/login", "?error=config");
  let response = NextResponse.next({ request });
  const supabase = createServerClient(url, key, {
    cookies: {
      getAll: () => request.cookies.getAll(),
      setAll(list) {
        list.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        list.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
      },
    },
  });
  const { data: { user } } = await supabase.auth.getUser(); // also refreshes the session cookie
  if (!user) {
    if (path.startsWith("/admin") && !isAdminLogin) return toLogin("/admin/login");
    if (path.startsWith("/account")) return toLogin("/login", "?next=" + encodeURIComponent(path));
  }
  return response;
}
export const config = { matcher: ["/admin/:path*", "/account/:path*"] };
