module.exports={reactStrictMode:true,experimental:{serverActions:{bodySizeLimit:'20mb'}},images:{remotePatterns:[{protocol:'https',hostname:'**.supabase.co'}]}};
