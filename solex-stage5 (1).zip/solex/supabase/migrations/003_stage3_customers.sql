-- Stage 3: customer addresses + tighter profile privileges. Run after 002.
create table if not exists addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  label text, full_name text not null, phone text not null,
  line1 text not null, line2 text, city text not null, state text not null,
  postal_code text, country text not null default 'Nigeria',
  is_default boolean not null default false,
  created_at timestamptz default now());
create unique index if not exists one_default_address_per_user on addresses(user_id) where is_default;
create index if not exists addresses_user_idx on addresses(user_id);
alter table addresses enable row level security;
drop policy if exists "own addresses" on addresses;
drop policy if exists "admin addresses read" on addresses;
create policy "own addresses" on addresses for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "admin addresses read" on addresses for select using (is_admin());

-- Customers may only edit their own name and phone (not role, not email).
revoke update on profiles from authenticated, anon;
grant update (full_name, phone) on profiles to authenticated;
-- Keep admins able to manage roles from the SQL editor (service role), not from the browser.
