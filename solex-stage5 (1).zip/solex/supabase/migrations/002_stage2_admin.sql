-- Stage 2: profiles auto-creation, storage bucket, tighter product visibility. Run after 001.
alter table profiles add column if not exists email text;
alter table product_images add column if not exists storage_path text;

create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as
$$ begin
  insert into profiles (id, email, full_name) values (new.id, new.email, new.raw_user_meta_data->>'full_name') on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();
-- backfill users created before this migration
insert into profiles (id, email) select id, email from auth.users on conflict (id) do update set email = excluded.email;

-- Inactive products are visible to admins only
drop policy if exists "products read" on products;
create policy "products read" on products for select using (is_active or is_admin());

-- Image storage (public read, admin-only write)
insert into storage.buckets (id, name, public) values ('product-images', 'product-images', true) on conflict (id) do nothing;
drop policy if exists "product images public read" on storage.objects;
drop policy if exists "product images admin insert" on storage.objects;
drop policy if exists "product images admin update" on storage.objects;
drop policy if exists "product images admin delete" on storage.objects;
create policy "product images public read" on storage.objects for select using (bucket_id = 'product-images');
create policy "product images admin insert" on storage.objects for insert with check (bucket_id = 'product-images' and public.is_admin());
create policy "product images admin update" on storage.objects for update using (bucket_id = 'product-images' and public.is_admin());
create policy "product images admin delete" on storage.objects for delete using (bucket_id = 'product-images' and public.is_admin());

-- Make a user an admin (run manually, after they have signed up):
-- update profiles set role = 'admin' where email = 'you@example.com';
