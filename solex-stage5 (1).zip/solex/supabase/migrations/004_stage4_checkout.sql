-- Stage 4: checkout, payments, shipping, server-side cart. Run after 003.
create sequence if not exists order_number_seq start 1001;
alter table orders
  add column if not exists order_number text unique default ('SOL-' || nextval('order_number_seq')::text),
  add column if not exists email text, add column if not exists customer_name text, add column if not exists phone text,
  add column if not exists subtotal numeric(12,2), add column if not exists shipping_fee numeric(12,2) not null default 0,
  add column if not exists paid_at timestamptz,
  add column if not exists stock_deducted boolean not null default false,
  add column if not exists stock_issue boolean not null default false,       -- paid, but stock ran out before payment confirmed
  add column if not exists confirmation_sent boolean not null default false,
  add column if not exists idempotency_key text unique;
alter table payments add column if not exists authorization_url text, add column if not exists raw jsonb, add column if not exists currency text default 'NGN';

create table if not exists shipping_rates (state text primary key, fee numeric(12,2) not null check (fee >= 0));
alter table shipping_rates enable row level security;
drop policy if exists "shipping read" on shipping_rates; drop policy if exists "shipping admin write" on shipping_rates;
create policy "shipping read" on shipping_rates for select using (true);
create policy "shipping admin write" on shipping_rates for all using (is_admin()) with check (is_admin());
-- PLACEHOLDER fees: change them in /admin/shipping before launch. 'DEFAULT' applies to any state without its own row.
insert into shipping_rates (state, fee) values ('DEFAULT', 3000), ('Lagos', 2000) on conflict do nothing;

create table if not exists cart_items (
  user_id uuid not null references profiles(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  size numeric(4,1) not null, color text not null default '', qty int not null check (qty between 1 and 10),
  primary key (user_id, product_id, size, color));
alter table cart_items enable row level security;
drop policy if exists "own cart" on cart_items;
create policy "own cart" on cart_items for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Orders/payments are written ONLY by server code using the service-role key (no insert policies exist for customers).
-- Atomic + idempotent payment confirmation. Called only after the server verified the transaction with Paystack.
create or replace function process_paid_order(p_reference text, p_amount_kobo bigint, p_currency text, p_raw jsonb)
returns text language plpgsql security definer set search_path = public as $$
declare pay payments%rowtype; ord orders%rowtype; it record;
begin
  select * into pay from payments where reference = p_reference for update;   -- row lock: concurrent calls queue here
  if not found then return 'not_found'; end if;
  if pay.status = 'success' then return 'already_processed'; end if;
  if p_currency is distinct from 'NGN' or p_amount_kobo <> round(pay.amount * 100) then
    update payments set status = 'mismatch', raw = p_raw where id = pay.id; return 'mismatch';
  end if;
  select * into ord from orders where id = pay.order_id for update;
  begin
    for it in select product_id, size, qty from order_items where order_id = ord.id loop
      update product_sizes set stock = stock - it.qty where product_id = it.product_id and size = it.size and stock >= it.qty;
      if not found then raise exception 'insufficient_stock'; end if;
    end loop;
    update orders set stock_deducted = true where id = ord.id;
  exception when others then   -- sub-transaction rolls back any partial deductions
    update orders set stock_issue = true where id = ord.id;
  end;
  update payments set status = 'success', verified_at = now(), raw = p_raw where id = pay.id;
  update orders set status = 'paid', paid_at = now() where id = ord.id;
  return 'processed';
end $$;
revoke all on function process_paid_order(text, bigint, text, jsonb) from public, anon, authenticated;
grant execute on function process_paid_order(text, bigint, text, jsonb) to service_role;
