-- SOLEX schema (Stage 1). Run in Supabase SQL editor.
create extension if not exists "pgcrypto";
create table brands (id uuid primary key default gen_random_uuid(), name text unique not null, slug text unique not null);
create table categories (id uuid primary key default gen_random_uuid(), name text unique not null, slug text unique not null);
create table products (
  id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null, description text,
  price numeric(12,2) not null check (price >= 0), sale_price numeric(12,2) check (sale_price >= 0),
  brand_id uuid references brands(id), category_id uuid references categories(id),
  gender text check (gender in ('men','women','kids','unisex')) default 'unisex',
  is_featured boolean default false, is_best_seller boolean default false, is_active boolean default true,
  created_at timestamptz default now());
create table product_images (id uuid primary key default gen_random_uuid(), product_id uuid references products(id) on delete cascade, url text not null, position int default 0);
create table product_sizes (id uuid primary key default gen_random_uuid(), product_id uuid references products(id) on delete cascade, size numeric(4,1) not null, stock int not null default 0 check (stock >= 0), unique(product_id,size));
create table product_colors (id uuid primary key default gen_random_uuid(), product_id uuid references products(id) on delete cascade, name text not null, hex text);
create table profiles (id uuid primary key references auth.users(id) on delete cascade, full_name text, phone text, role text not null default 'customer' check (role in ('customer','admin')));
create table orders (id uuid primary key default gen_random_uuid(), user_id uuid references profiles(id), status text not null default 'pending' check (status in ('pending','paid','processing','shipped','delivered','cancelled')), total numeric(12,2) not null, shipping_address jsonb, created_at timestamptz default now());
create table order_items (id uuid primary key default gen_random_uuid(), order_id uuid references orders(id) on delete cascade, product_id uuid references products(id), name text, size numeric(4,1), color text, qty int not null check (qty>0), unit_price numeric(12,2) not null);
create table payments (id uuid primary key default gen_random_uuid(), order_id uuid references orders(id), reference text unique not null, amount numeric(12,2), status text default 'initialized', verified_at timestamptz);
create table wishlists (user_id uuid references profiles(id) on delete cascade, product_id uuid references products(id) on delete cascade, primary key(user_id,product_id));
create table discounts (id uuid primary key default gen_random_uuid(), code text unique not null, percent int check (percent between 1 and 100), active boolean default true, expires_at timestamptz);

create or replace function is_admin() returns boolean language sql security definer stable as
$$ select exists(select 1 from profiles where id = auth.uid() and role = 'admin') $$;

alter table brands enable row level security; alter table categories enable row level security; alter table products enable row level security;
alter table product_images enable row level security; alter table product_sizes enable row level security; alter table product_colors enable row level security;
alter table profiles enable row level security; alter table orders enable row level security; alter table order_items enable row level security;
alter table payments enable row level security; alter table wishlists enable row level security; alter table discounts enable row level security;

-- Public catalogue: read for everyone, write for admins only
do $$ declare t text; begin foreach t in array array['brands','categories','products','product_images','product_sizes','product_colors'] loop
  execute format('create policy "%1$s read" on %1$s for select using (true)', t);
  execute format('create policy "%1$s admin write" on %1$s for all using (is_admin()) with check (is_admin())', t);
end loop; end $$;
create policy "own profile read" on profiles for select using (id = auth.uid() or is_admin());
create policy "own profile update" on profiles for update using (id = auth.uid()) with check (id = auth.uid() and role = 'customer');
create policy "own orders read" on orders for select using (user_id = auth.uid() or is_admin());
create policy "admin orders update" on orders for update using (is_admin());
create policy "own order items read" on order_items for select using (exists(select 1 from orders o where o.id = order_id and (o.user_id = auth.uid() or is_admin())));
create policy "admin payments read" on payments for select using (is_admin());
create policy "own wishlist" on wishlists for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "admin discounts" on discounts for all using (is_admin()) with check (is_admin());
-- Orders and payments are created/updated only by server routes using the service-role key (Stage 3).
