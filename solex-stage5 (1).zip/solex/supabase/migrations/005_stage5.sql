-- Stage 5: wishlist, discounts, contact, tracking history, rate limiting, account deletion support. Run after 004.
alter table wishlists add column if not exists created_at timestamptz default now();

alter table discounts
  add column if not exists type text not null default 'percent' check (type in ('percent','fixed')),
  add column if not exists amount numeric(12,2) check (amount > 0),
  add column if not exists min_subtotal numeric(12,2) not null default 0,
  add column if not exists usage_limit int check (usage_limit > 0),
  add column if not exists used_count int not null default 0,
  add column if not exists starts_at timestamptz,
  add column if not exists description text,
  add column if not exists is_public boolean not null default false,
  add column if not exists created_at timestamptz default now();
alter table discounts drop constraint if exists discounts_value_ck;
alter table discounts add constraint discounts_value_ck check ((type = 'percent' and percent between 1 and 100) or (type = 'fixed' and amount > 0)) not valid;
-- Codes are private (admin-only) except offers the admin marks public for the homepage banner.
drop policy if exists "public promos read" on discounts;
create policy "public promos read" on discounts for select using (is_public and active and (starts_at is null or starts_at <= now()) and (expires_at is null or expires_at > now()));
create table if not exists discount_redemptions (id uuid primary key default gen_random_uuid(), discount_id uuid references discounts(id) on delete cascade, order_id uuid unique references orders(id) on delete cascade, created_at timestamptz default now());
alter table discount_redemptions enable row level security;
drop policy if exists "admin redemptions read" on discount_redemptions;
create policy "admin redemptions read" on discount_redemptions for select using (is_admin());

alter table orders
  add column if not exists discount_id uuid references discounts(id) on delete set null,
  add column if not exists discount_code text,
  add column if not exists discount_amount numeric(12,2) not null default 0,
  add column if not exists courier text, add column if not exists tracking_number text;
-- Deleting an account must not be blocked by past orders: orders are kept (anonymised by the app), unlinked from the user.
alter table orders drop constraint if exists orders_user_id_fkey;
alter table orders add constraint orders_user_id_fkey foreign key (user_id) references profiles(id) on delete set null;

create table if not exists order_events (id uuid primary key default gen_random_uuid(), order_id uuid not null references orders(id) on delete cascade, status text not null, note text, created_at timestamptz default now());
create index if not exists order_events_order_idx on order_events(order_id, created_at);
alter table order_events enable row level security;
drop policy if exists "own order events read" on order_events;
create policy "own order events read" on order_events for select using (is_admin() or exists (select 1 from orders o where o.id = order_id and o.user_id = auth.uid()));
create or replace function log_order_event() returns trigger language plpgsql security definer set search_path = public as
$$ begin
  if tg_op = 'INSERT' or new.status is distinct from old.status then insert into order_events (order_id, status) values (new.id, new.status); end if;
  return new;
end $$;
drop trigger if exists orders_log_event on orders;
create trigger orders_log_event after insert or update of status on orders for each row execute function log_order_event();
insert into order_events (order_id, status, created_at) select id, status, coalesce(paid_at, created_at) from orders o where not exists (select 1 from order_events e where e.order_id = o.id);

create table if not exists contact_messages (id uuid primary key default gen_random_uuid(), name text not null, email text not null, subject text not null, message text not null,
  user_id uuid references profiles(id) on delete set null, status text not null default 'new' check (status in ('new','handled')), created_at timestamptz default now());
alter table contact_messages enable row level security;
drop policy if exists "admin messages" on contact_messages;
create policy "admin messages" on contact_messages for all using (is_admin()) with check (is_admin());
-- No public insert policy: messages are written by the server after validation and rate limiting.

create table if not exists rate_events (key text not null, created_at timestamptz not null default now());
create index if not exists rate_events_idx on rate_events (key, created_at);
alter table rate_events enable row level security; -- service role only

-- Same function as Stage 4, plus: count discount usage once, only after verified payment.
create or replace function process_paid_order(p_reference text, p_amount_kobo bigint, p_currency text, p_raw jsonb)
returns text language plpgsql security definer set search_path = public as $$
declare pay payments%rowtype; ord orders%rowtype; it record;
begin
  select * into pay from payments where reference = p_reference for update;
  if not found then return 'not_found'; end if;
  if pay.status = 'success' then return 'already_processed'; end if;
  if p_currency is distinct from 'NGN' or p_amount_kobo <> round(pay.amount * 100) then
    update payments set status = 'mismatch', raw = p_raw where id = pay.id; return 'mismatch';
  end if;
  select * into ord from orders where id = pay.order_id for update;
  begin
    for it in select product_id, size, qty from order_items where order_id = ord.id loop
      update product_sizes set stock = stock - it.qty where product_id = it.product_id and size = it.size and stock >= it.qty;
      if not found then raise exception 'insufficient_stock'; end if;
    end loop;
    update orders set stock_deducted = true where id = ord.id;
  exception when others then
    update orders set stock_issue = true where id = ord.id;
  end;
  update payments set status = 'success', verified_at = now(), raw = p_raw where id = pay.id;
  update orders set status = 'paid', paid_at = now() where id = ord.id;
  if ord.discount_id is not null then
    insert into discount_redemptions (discount_id, order_id) values (ord.discount_id, ord.id) on conflict do nothing;
    if found then update discounts set used_count = used_count + 1 where id = ord.discount_id; end if;
  end if;
  return 'processed';
end $$;
revoke all on function process_paid_order(text, bigint, text, jsonb) from public, anon, authenticated;
grant execute on function process_paid_order(text, bigint, text, jsonb) to service_role;
