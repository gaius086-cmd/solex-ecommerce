# SOLEX: custom footwear store

Next.js 14 + Tailwind + Supabase + Paystack. Independent, custom-coded (no Shopify/WooCommerce). Built in stages 1-5. **The code has not been run by its author; test everything after setup.**

## Features
- **Storefront:** home (featured, best sellers, new arrivals, brands, public offers), shop with search / brand / category / size / price filters, product pages, wishlist hearts.
- **Cart and checkout:** browser cart for guests, saved to the account when logged in; guest and member checkout; delivery fees by state; discount codes; Paystack payment.
- **Accounts:** register, login, email confirmation, password reset, profile, addresses, wishlist, order history with timelines, account deletion.
- **Orders:** unique order numbers, guest tracking (order number + email), status emails.
- **Contact:** validated, rate-limited form; messages saved for the admin.
- **Admin (`/admin`):** dashboard, products (multi-image upload, sizes, colours, stock), inventory, orders (status, courier, tracking), customers, shipping fees, discount codes, messages.

## Setup
1. `npm install`
2. Supabase SQL editor: run `supabase/migrations/001` to `005` in order.
3. Supabase Authentication: enable Email provider; set Site URL; add `<site>/auth/callback` to Redirect URLs. Add your own SMTP before launch (built-in sender is heavily rate-limited).
4. Create a user (Authentication > Users), then make them admin: `update profiles set role = 'admin' where email = 'you@example.com';`
5. Copy `.env.example` to `.env.local` and fill it in (see below). `npm run dev`.
6. Admin login: `/admin/login`. Customers log in at `/login`.

## Environment variables
| Variable | Purpose |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` | public Supabase keys |
| `SUPABASE_SERVICE_ROLE_KEY` | **server only**; orders, payments, tracking, contact, discounts, account deletion |
| `PAYSTACK_SECRET_KEY` | **server only**; use the test key first |
| `RESEND_API_KEY`, `EMAIL_FROM` | order and status emails (optional; verify a domain in Resend) |
| `CONTACT_TO_EMAIL` | also email contact messages to this address (optional) |
| `NEXT_PUBLIC_SITE_URL` | your site URL (also set on Vercel) |

Never put server-only keys in a `NEXT_PUBLIC_` variable.

## Payments
1. Paystack dashboard: copy the test secret key. Set the webhook URL to `https://YOUR-DOMAIN/api/paystack/webhook` (locally use a tunnel such as ngrok; the result page also verifies, so checkout works without the webhook).
2. In `/admin/shipping` replace the placeholder fees (DEFAULT 3000, Lagos 2000).
3. Test with Paystack test cards before switching to live keys.

How it stays safe: the browser sends only product id, size, colour and quantity; prices, stock, shipping and discounts come from the database. Orders/payments are created by server code only. An order becomes `paid` only inside the database function `process_paid_order`, after the server verified the transaction with Paystack (status, amount in kobo, NGN). The result page and the signature-checked webhook both use it, under a row lock, so repeats are harmless. Stock is deducted only then; if stock ran out meanwhile the order is flagged `stock_issue` for you to refund or resolve.

## Admin security
`middleware.js` blocks anonymous visitors; every admin page and action calls `requireAdmin()` (role read from the database); Row Level Security enforces the same in the database. Customers cannot change their role or email.

## Stage 5 notes
- **Discounts:** validated on the server when quoting and again when the order is created; they reduce the subtotal only. Usage is counted once, after verified payment, so abandoned checkouts do not use up limits. Limits are not reserved: with 1 use left, two people could both start checkout and both be honoured if both pay. Admin times are Nigeria time (WAT).
- **Tracking:** order number + checkout email, rate-limited (10 per 15 min per visitor), identical failure message; shows no address or phone.
- **Contact:** honeypot, validation, rate limits (5/hour per visitor, 3/hour per email). Always saved in `/admin/messages`.
- **Status emails:** sent when an admin changes status to processing, shipped, delivered or cancelled in `/admin/orders`. Changes made directly in the Supabase table editor send nothing.
- **Account deletion:** needs password + typing DELETE; blocked for admins and while an order is paid/processing/shipped (or a checkout started in the last 2 hours). Orders are kept without personal details for bookkeeping. Check your legal record-keeping rules.
- **Rate limiting** uses the `rate_events` table and the hashed `x-forwarded-for` IP (set by Vercel).

## Known limitations
No refunds from the dashboard, no per-customer discount limits, no product reviews, no email change, address edit works but there is no address book import. Cancelling an order does not restock paid items. The Next.js `images` setup only allows Supabase-hosted images. Stock is not reserved during checkout.

## Deploy
Push to GitHub, import into Vercel, add all environment variables, set the Supabase redirect URL and Paystack webhook to the live domain.
